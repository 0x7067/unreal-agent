#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
go test -race ./cmd/internal/durablejob -count=1 -v >'/tmp/unreal-agent-m43-adapter-focused.hF8GaI/test.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m43-adapter-focused.hF8GaI/exit-code';exit $rc

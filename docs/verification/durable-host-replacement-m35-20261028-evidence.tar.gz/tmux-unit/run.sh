#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
python3 -I .claude/skills/verify-unreal-agent-tui/scripts/durable_host_upgrade.py '/data/development/projects/0x7067/unreal-agent' '/tmp/u35.TGu78h' '/tmp/unreal-agent-m35-build.eVfppd/runner-a' '/tmp/unreal-agent-m35-build.eVfppd/runner-b' '/tmp/unreal-agent-m35-build.eVfppd/runner-bad-host' >'/tmp/unreal-agent-m35-ui.2CxcFn/proof.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m35-ui.2CxcFn/exit-code';exit $rc

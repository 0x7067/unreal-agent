#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
go test -race ./cmd/internal/workerhost ./cmd/internal/resident ./cmd/internal/residentcli ./cmd/internal/durablejob -run '^TestM34|^TestRuntimeCandidateFailure|^TestRuntimeHostRetirement' -count=1 -v >'/tmp/unreal-agent-m35-focused.fhc0De/test.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m35-focused.fhc0De/exit-code';exit $rc

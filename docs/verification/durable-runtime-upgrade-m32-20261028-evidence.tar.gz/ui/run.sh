#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
python3 -I .claude/skills/verify-unreal-agent-tui/scripts/durable_runtime_upgrade.py '/data/development/projects/0x7067/unreal-agent' '/tmp/u32.5XYkbO' '/tmp/unreal-agent-m32-build.5svHLC/runner-a' '/tmp/unreal-agent-m32-build.5svHLC/runner-b' '/tmp/unreal-agent-m32-build.5svHLC/runner-incompatible' >'/tmp/unreal-agent-m32-ui.E2OJd3/proof.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m32-ui.E2OJd3/exit-code';exit $rc

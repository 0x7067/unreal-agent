#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
go test -race ./cmd/internal/resident -run '^TestRuntime' -count=1 -v >'/tmp/unreal-agent-m32-focused.gUlz8c/test.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m32-focused.gUlz8c/exit-code';exit $rc

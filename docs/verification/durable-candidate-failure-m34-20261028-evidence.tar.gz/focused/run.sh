#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
go test -race ./cmd/internal/workerhost ./cmd/internal/resident -run '^TestM34|^TestRuntimeCandidateFailure' -count=1 -v >'/tmp/unreal-agent-m34-focused.fkcXql/test.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m34-focused.fkcXql/exit-code';exit $rc

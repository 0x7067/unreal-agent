#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
python3 -I .claude/skills/verify-unreal-agent-tui/scripts/durable_runtime_failure.py '/data/development/projects/0x7067/unreal-agent' '/tmp/u34.argi46' '/tmp/unreal-agent-m34-build.5VjzIc/runner-a' '/tmp/unreal-agent-m34-build.5VjzIc/runner-b' '/tmp/unreal-agent-m34-build.5VjzIc/runner-startup-failure' >'/tmp/unreal-agent-m34-ui.MQA8ig/proof.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m34-ui.MQA8ig/exit-code';exit $rc

python3 '/tmp/unreal-agent-m34-validation.gZat0u/manifest.py' > '/tmp/unreal-agent-m34-validation.gZat0u/source.before.sha256'
rc=0
for phase in check build test; do
 printf '%s\n' "$phase" > '/tmp/unreal-agent-m34-validation.gZat0u/phase'
 make "$phase" > '/tmp/unreal-agent-m34-validation.gZat0u'/make-"$phase".log 2>&1
 rc=$?
 if [ "$rc" != 0 ]; then break;fi
done
python3 '/tmp/unreal-agent-m34-validation.gZat0u/manifest.py' > '/tmp/unreal-agent-m34-validation.gZat0u/source.after.sha256'
if ! cmp -s '/tmp/unreal-agent-m34-validation.gZat0u/source.before.sha256' '/tmp/unreal-agent-m34-validation.gZat0u/source.after.sha256';then rc=97;fi
printf '%s\n' "$rc" > '/tmp/unreal-agent-m34-validation.gZat0u/exit-code.tmp';mv '/tmp/unreal-agent-m34-validation.gZat0u/exit-code.tmp' '/tmp/unreal-agent-m34-validation.gZat0u/exit-code'
printf '%s\n' finished > '/tmp/unreal-agent-m34-validation.gZat0u/phase'
exit "$rc"

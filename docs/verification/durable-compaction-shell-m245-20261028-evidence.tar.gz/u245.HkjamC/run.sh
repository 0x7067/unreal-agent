python3 -I .claude/skills/verify-unreal-agent-tui/scripts/durable_reconnect.py '/data/development/projects/0x7067/unreal-agent' '/tmp/u245.HkjamC' > '/tmp/u245.HkjamC/driver.log' 2>&1
rc=$?
printf '%s\n' "$rc" > '/tmp/u245.HkjamC/exit-code'
exit "$rc"

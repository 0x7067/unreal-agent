python3 -I .claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py '/data/development/projects/0x7067/unreal-agent' '/tmp/u245.YqGJDT' > '/tmp/u245.YqGJDT/driver.log' 2>&1
rc=$?
printf '%s\n' "$rc" > '/tmp/u245.YqGJDT/exit-code'
exit "$rc"

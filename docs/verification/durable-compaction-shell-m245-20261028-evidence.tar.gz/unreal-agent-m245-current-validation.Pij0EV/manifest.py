import hashlib,subprocess
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','cmd','harness','internal','go.mod','go.sum','Makefile','docs/formal']).split(b'\0')
for name in sorted(set(filter(None,names))):
 with open(name,'rb')as f:print(hashlib.sha256(f.read()).hexdigest()+'  '+name.decode())

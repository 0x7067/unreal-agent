python3 -I '/data/development/projects/0x7067/unreal-agent/.claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py' '/data/development/projects/0x7067/unreal-agent' '/tmp/u22.W6Fceo' > '/tmp/u22.W6Fceo'/driver.log 2>&1
rc=$?
printf "%s\n" "$rc" > '/tmp/u22.W6Fceo'/exit-code
exit "$rc"

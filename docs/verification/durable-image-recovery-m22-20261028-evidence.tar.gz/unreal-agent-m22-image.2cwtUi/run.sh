go test -race ./cmd/internal/workerhost -run "^TestM22" -count=1 -timeout=120s -v > '/tmp/unreal-agent-m22-image.2cwtUi'/test.log 2>&1
rc=$?
printf "%s\n" "$rc" > '/tmp/unreal-agent-m22-image.2cwtUi'/exit-code
exit "$rc"

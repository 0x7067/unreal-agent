// Package recoverygate validates the narrow allow-list for automatic recovery.
// It performs no dispatch or I/O; callers must separately enforce ownership and
// keep terminal history inert.
package recoverygate

import (
	"bytes"
	"fmt"
	"slices"
	"strconv"

	"github.com/unreallabsai/unreal-agent/harness/operation"
)

// Validate refuses every nonterminal operation except a supported, decodable
// ready Value or ready/awaiting ViewImage without a result. Terminal history is not decoded:
// accepting it here never authorizes redispatch. The input is not modified.
// Refusals use a full stable ordering, independent of input/map iteration order.
func Validate(operations []operation.Operation) error {
	ordered := slices.Clone(operations)
	slices.SortFunc(ordered, compare)
	for _, op := range ordered {
		switch op.Status {
		case operation.StatusCompleted, operation.StatusFailed, operation.StatusCanceled:
			continue
		}
		if op.ID == "" {
			return refuse(op, "missing operation identity", operation.ErrUnsupported)
		}
		if op.Status != operation.StatusReady && !(op.Type == operation.TypeViewImage && op.Version == operation.VersionViewImage && op.Status == operation.StatusAwaiting) {
			return refuse(op, "only approved recovery states may recover", operation.ErrUnsupported)
		}
		switch {
		case op.Type == operation.TypeValue && op.Version == operation.VersionValue:
			if _, err := operation.DecodeValue(op); err != nil {
				return refuse(op, "invalid value state", err)
			}
		case op.Type == operation.TypeViewImage && op.Version == operation.VersionViewImage:
			state, err := operation.DecodeViewImageState(op)
			if err != nil {
				return refuse(op, "invalid image state", err)
			}
			if state.Result != nil {
				return refuse(op, "unfinished image state contains a result", operation.ErrUnsupported)
			}
		default:
			return refuse(op, "unclassified initial operation intent", operation.ErrUnsupported)
		}
	}
	return nil
}

// compare includes every serialized field, so duplicate IDs cannot make the
// selected diagnostic depend on the order of a map-derived input slice.
func compare(a, b operation.Operation) int {
	if n := compareOrdered(a.ID, b.ID); n != 0 {
		return n
	}
	if n := compareOrdered(a.Type, b.Type); n != 0 {
		return n
	}
	if n := compareOrdered(a.Version, b.Version); n != 0 {
		return n
	}
	if n := compareOrdered(a.Status, b.Status); n != 0 {
		return n
	}
	if n := bytes.Compare(a.State, b.State); n != 0 {
		return n
	}
	if n := bytes.Compare(a.Idempotency, b.Idempotency); n != 0 {
		return n
	}
	return compareOrdered(a.MaxOutputLength, b.MaxOutputLength)
}

func compareOrdered[T ~string | ~uint32 | ~int](a, b T) int {
	if a < b {
		return -1
	}
	if a > b {
		return 1
	}
	return 0
}

// refusal retains the original decoder cause for errors.Is/As/Unwrap while
// exposing only bounded diagnostic text (at most 2048 bytes).
type refusal struct {
	message string
	cause   error
}

func (e *refusal) Error() string { return e.message }
func (e *refusal) Unwrap() error { return e.cause }

func refuse(op operation.Operation, reason string, cause error) error {
	// Quote bounded prefixes before formatting; hostile control bytes cannot
	// inject log lines, and arbitrarily large identifiers cannot expand the log.
	field := func(s string) string { return strconv.QuoteToASCII(clip(s, 48)) }
	message := fmt.Sprintf("recovery refused: id=%s type=%s version=%d status=%s: %s: %s",
		field(string(op.ID)), field(string(op.Type)), op.Version, field(string(op.Status)), reason, clip(cause.Error(), 512))
	return &refusal{message: clip(message, 2048), cause: cause}
}

func clip(s string, limit int) string {
	if len(s) <= limit {
		return s
	}
	return s[:limit-3] + "..."
}

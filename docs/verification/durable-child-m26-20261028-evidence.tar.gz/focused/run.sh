#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
go test -race ./cmd/internal/durablechild ./cmd/internal/workerruntime ./cmd/internal/subagent ./harness/tool/subagent ./harness/sessionstore ./cmd/internal/recoverygate -count=1 -v >'/tmp/unreal-agent-m26-focused.MtlUo9/test.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m26-focused.MtlUo9/exit-code';exit $rc

#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
python3 -I .claude/skills/verify-unreal-agent-tui/scripts/durable_reconnect.py /data/development/projects/0x7067/unreal-agent '/tmp/u26.oCaCBF' >'/tmp/u26.oCaCBF/driver.log' 2>&1
rc=$?;echo $rc >'/tmp/u26.oCaCBF/exit-code';exit $rc

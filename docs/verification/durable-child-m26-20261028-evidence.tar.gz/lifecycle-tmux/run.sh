#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
python3 -I .claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py /data/development/projects/0x7067/unreal-agent '/tmp/u26.JlAcEY' >'/tmp/u26.JlAcEY/driver.log' 2>&1
rc=$?;echo $rc >'/tmp/u26.JlAcEY/exit-code';exit $rc

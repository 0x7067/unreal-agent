#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
python3 -I .claude/skills/verify-unreal-agent-tui/scripts/durable_runtime_drain.py '/data/development/projects/0x7067/unreal-agent' '/tmp/u33.75P2pE' '/tmp/unreal-agent-m33-build.tzMeYm/runner-a' '/tmp/unreal-agent-m33-build.tzMeYm/runner-b' '/tmp/unreal-agent-m33-build.tzMeYm/runner-incompatible' >'/tmp/unreal-agent-m33-ui.4RDgpx/proof.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m33-ui.4RDgpx/exit-code';exit $rc

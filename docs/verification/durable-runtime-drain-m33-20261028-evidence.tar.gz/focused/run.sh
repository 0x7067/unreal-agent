#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
go test -race ./cmd/internal/resident -run '^TestRuntimeNaturalDrain' -count=1 -v >'/tmp/unreal-agent-m33-focused.jv5VYm/test.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m33-focused.jv5VYm/exit-code';exit $rc

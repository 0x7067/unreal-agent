#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
(cd cmd/unreal-agent-tui && go build -race -o '/tmp/unreal-agent-m33-race-build.OEKfVg/unreal-agent-tui-race' .) >'/tmp/unreal-agent-m33-race-build.OEKfVg/build.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m33-race-build.OEKfVg/exit-code';exit $rc

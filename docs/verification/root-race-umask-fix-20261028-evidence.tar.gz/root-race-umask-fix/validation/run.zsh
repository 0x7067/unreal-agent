#!/usr/bin/zsh
cd /data/development/projects/0x7067/unreal-agent ||exit 90
umask 077
D=/tmp/unreal-agent-umask-fix.TUGDn4
python3 "$D/manifest.py" >"$D/source.before.sha256"
git ls-files --cached -z cmd harness internal go.mod go.sum Makefile docs/formal >"$D/tracked.before.zlist"
git ls-files --others --exclude-standard -z cmd harness internal go.mod go.sum Makefile docs/formal >"$D/untracked.before.zlist"
go list ./... |sort >"$D/packages.root.before"
go -C cmd/unreal-agent-tui list ./... |sort >"$D/packages.tui.before"
print -r -- "umask=$(umask) GOFLAGS=$GOFLAGS HOME=$HOME TMPDIR=$TMPDIR" >"$D/environment.txt"
rc=0
for mask in 022 077;do
 print -r -- "focused-$mask" >"$D/phase"
 (umask "$mask"; go test -race -count=1 ./harness/ingress ./harness/operation ./harness/taskgraph -run '^(TestPathConfinementAndPrivatePermissions|TestRemoteArtifactsPathFailures|TestFingerprintContentAndMembership)$' -v) >"$D/focused-$mask.log" 2>&1
 phase_rc=$?;print -r -- "$phase_rc" >"$D/focused-$mask.exit"
 if [[ $phase_rc != 0 ]];then rc=$phase_rc;break;fi
done
if [[ $rc == 0 ]];then
 for phase in check build test;do
  print -r -- "$phase" >"$D/phase"
  make "$phase" >"$D/make-$phase.log" 2>&1
  phase_rc=$?;print -r -- "$phase_rc" >"$D/make-$phase.exit"
  if [[ $phase_rc != 0 ]];then rc=$phase_rc;break;fi
 done
fi
python3 "$D/manifest.py" >"$D/source.after.sha256"
git ls-files --cached -z cmd harness internal go.mod go.sum Makefile docs/formal >"$D/tracked.after.zlist"
git ls-files --others --exclude-standard -z cmd harness internal go.mod go.sum Makefile docs/formal >"$D/untracked.after.zlist"
go list ./... |sort >"$D/packages.root.after"
go -C cmd/unreal-agent-tui list ./... |sort >"$D/packages.tui.after"
cmp -s "$D/source.before.sha256" "$D/source.after.sha256" ||rc=97
print -r -- "$rc" >"$D/exit-code";print -r -- finished >"$D/phase";exit "$rc"

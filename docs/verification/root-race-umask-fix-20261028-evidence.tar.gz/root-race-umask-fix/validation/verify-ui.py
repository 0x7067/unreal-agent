from pathlib import Path
import hashlib,json,subprocess,sys
p=Path(sys.argv[1]);u=p/'ui';r=Path((u/'root').read_text().strip());e=r/'lifecycle/evidence'
assert (u/'exit-code').read_text().strip()=='0';cleanup=json.loads((e/'cleanup.json').read_text());assert len(cleanup)==13 and all(cleanup.values())
result=json.loads((e/'m4-workloads-result.json').read_text());assert result['old_worker_pidfd_exited'] and result['old_host_actual_wait']==1 and result['old_host_pid']!=result['new_host_pid'] and result['old_incarnation']!=result['new_incarnation'];assert result['remote_process_survived'] and result['execution_effects']==1 and result['terminal_output']=='firstsecond';assert result['executor_actual_wait_zero'] and result['provider_threads_joined'] and result['credentials_absent'];assert result['remote_provider_calls']==2 and result['auxiliary_provider_calls']==4
base_calls=len(json.loads((e/'provider-calls.json').read_text()));assert base_calls==2;assert base_calls+result['remote_provider_calls']+result['auxiliary_provider_calls']==8
receipts=list(e.glob('*-tty-join.json'));assert len(receipts)==4
for f in receipts:
 v=json.loads(f.read_text());assert v['child_waited'] and v['returncode']==0 and v['tty_exact'] and not v['forced'] and v['wrapper_exit_pidfd_observed']
inputs=(u/'input.before.sha256').read_text();assert inputs==(u/'input.after.sha256').read_text()
for line in inputs.splitlines():
 digest,path=line.split('  ',1);assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
(u/'input.current.sha256').write_text(inputs)
unit=(u/'unit').read_text().strip();cg=(u/'cgroup').read_text().strip();raw=subprocess.check_output(['systemctl','--user','show',unit,'-p','LoadState','-p','MainPID','-p','Result','-p','ExecMainStatus','-p','ActiveState'],text=True);state=dict(line.split('=',1) for line in raw.splitlines());assert state['LoadState']=='loaded' and state['MainPID']=='0' and state['Result']=='success' and state['ExecMainStatus']=='0',state;assert not Path('/sys/fs/cgroup'+cg).exists();subprocess.run(['systemctl','--user','stop',unit],check=True);assert not Path('/sys/fs/cgroup'+cg).exists()
(u/'unit-drain.json').write_text(json.dumps({'unit':unit,'original_control_group':cg,'before_exact_stop':state,'exact_stop_returncode':0,'exact_cgroup_absent_before_and_after':True},indent=2)+'\n');(u/'journal.jsonl').write_text(subprocess.check_output(['journalctl','--user','-u',unit,'-n','40','--no-pager','-o','json'],text=True))
summary={'status':'PASS','actual_installed_paths':True,'four_frontend_actual_waits_zero_and_tty_exact':True,'old_worker_pidfd_exit':True,'old_host_wait':1,'fresh_incarnation_same_remote_job':True,'remote_effect_count':1,'executor_actual_wait':0,'cleanup_true':13,'provider_calls':8,'base_provider_calls':2,'remote_provider_calls':2,'auxiliary_provider_calls':4,'binary_driver_base_before_after_current_equal':True,'unit_drained':True};(u/'validation-result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

#!/usr/bin/zsh
sha256sum /tmp/unreal-agent-umask-fix.TUGDn4/installed-ui.py /data/development/projects/0x7067/unreal-agent/.claude/skills/verify-unreal-agent-tui/scripts/durable_workloads.py /data/development/projects/0x7067/unreal-agent/.claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py /home/denguinho/.local/bin/unreal-agent-runner /home/denguinho/.local/bin/unreal-agent-tui >/tmp/unreal-agent-umask-fix.TUGDn4/ui/input.before.sha256
python3 -I /tmp/unreal-agent-umask-fix.TUGDn4/installed-ui.py /data/development/projects/0x7067/unreal-agent /tmp/uu.PEKH00 >/tmp/unreal-agent-umask-fix.TUGDn4/ui/driver.log 2>&1
rc=$?
sha256sum /tmp/unreal-agent-umask-fix.TUGDn4/installed-ui.py /data/development/projects/0x7067/unreal-agent/.claude/skills/verify-unreal-agent-tui/scripts/durable_workloads.py /data/development/projects/0x7067/unreal-agent/.claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py /home/denguinho/.local/bin/unreal-agent-runner /home/denguinho/.local/bin/unreal-agent-tui >/tmp/unreal-agent-umask-fix.TUGDn4/ui/input.after.sha256
cmp -s /tmp/unreal-agent-umask-fix.TUGDn4/ui/input.before.sha256 /tmp/unreal-agent-umask-fix.TUGDn4/ui/input.after.sha256 ||rc=97
print -r -- "$rc" >/tmp/unreal-agent-umask-fix.TUGDn4/ui/exit-code
exit $rc

import hashlib,json,os,pathlib,sys
D=pathlib.Path(sys.argv[1]);ROOT=pathlib.Path((D/'root').read_text().strip());I=json.loads((D/'inputs.json').read_text());REPO=pathlib.Path(I['repo'])
SETUP=r'''
    executor_unit=None
    executor_cgroup=None
    executor_pidfd=None
    worker_pidfd=None
    test_pidfd=None
    dog_result={}
'''
MODEL=r'''
    class Model(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_POST(self):
            handler_threads.append(threading.current_thread())
            raw=self.rfile.read(int(self.headers['Content-Length']))
            body=json.loads(raw);calls.append(body)
            number=len(calls)
            if number==1:
                output=[{'type':'function_call','id':'dogfood-tests','call_id':'dogfood-tests','name':'RunTrustedJob','arguments':'{"job":"repo-race-tests"}'}]
            elif number==2:
                op=latest_operation();assert op and op['Status'] in ('completed','failed')
                receipt=json.loads((D/'job-result.json').read_text())
                label='DOGFOOD_TESTS_PASSED' if receipt['job_exit']==0 else 'DOGFOOD_TESTS_FAILED'
                output=[{'type':'message','id':'dogfood-outcome','role':'assistant','content':[{'type':'output_text','text':label+' root='+str(receipt['root_exit'])+' tui='+str(receipt['tui_exit'])}]}]
            else:raise AssertionError('duplicate model continuation '+str(number))
            event={'type':'response.completed','response':{'id':'dogfood-'+str(number),'status':'completed','output':output,'usage':{'input_tokens':1,'output_tokens':1}}}
            self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
            self.wfile.write(('data: '+json.dumps(event)+'\n\n').encode())
'''
PREPARE=r'''
        import base64,secrets,fcntl
        job_home=ROOT/'job-home';job_home.mkdir(mode=0o700)
        job_tmp=ROOT/'jt';job_tmp.mkdir(mode=0o700)
        token=secrets.token_urlsafe(40)
        cert,key=run/'executor-cert.pem',run/'executor-key.pem'
        subprocess.run(['openssl','req','-x509','-newkey','ed25519','-nodes','-days','1','-subj','/CN=executor.test','-addext','subjectAltName=DNS:executor.test','-out',str(cert),'-keyout',str(key)],check=True,env=env,stdout=subprocess.DEVNULL,stderr=(run/'cert-stderr.txt').open('w'))
        cert.chmod(0o600);key.chmod(0o600)
        job_env=['PATH='+I['goroot']+'/bin:/usr/bin:/bin','GOROOT='+I['goroot'],'HOME='+str(job_home),'TMPDIR='+str(job_tmp),'GOCACHE='+I['gocache'],'GOMODCACHE='+I['gomodcache'],'GOPATH='+str(job_home/'go'),'GOTOOLCHAIN=local','GOPROXY=off','GOSUMDB=off','GOFLAGS=-p=2','LANG=C.UTF-8']
        cfg=run/'executor.json';cfg.write_text(json.dumps({'Version':1,'Directory':str(run/'executor'),'EnvironmentID':'dogfood-tests','ControllerIDs':['session-'+hashlib.sha256(sid.encode()).hexdigest()[:32]],'TLSAddress':'127.0.0.1:0','CertFile':str(cert),'KeyFile':str(key),'Jobs':{'repo-race-tests':{'Path':'/usr/bin/zsh','Args':[str(D/'job.zsh'),str(D)],'Dir':I['snapshot'],'Env':job_env}}}));cfg.chmod(0o600)
        executor_unit='unreal-agent-dogfood-executor-'+sid[-12:]+'.service'
        executor_start=D/'executor.zsh'
        executor_start.write_text('exec '+shlex.join([str(runner),'job-executor','--config',str(cfg)])+' >'+shlex.quote(str(D/'executor-ready.json'))+' 2>'+shlex.quote(str(D/'executor-stderr.txt'))+'\n');executor_start.chmod(0o700)
        exec_env=os.environ.copy();exec_env['UNREAL_AGENT_EXECUTOR_TOKEN']=token
        subprocess.run(['systemd-run','--user','--unit',executor_unit,'--remain-after-exit','--setenv=UNREAL_AGENT_EXECUTOR_TOKEN','--property=RuntimeMaxSec=22min','--property=TimeoutStopSec=15s','--property=KillMode=control-group','--','/usr/bin/zsh',str(executor_start)],env=exec_env,check=True,capture_output=True,text=True)
        executor_cgroup=subprocess.check_output(['systemctl','--user','show',executor_unit,'-p','ControlGroup','--value'],text=True).strip()
        (D/'executor-unit.json').write_text(json.dumps({'unit':executor_unit,'cgroup':executor_cgroup})+'\n')
        ready_path=D/'executor-ready.json'
        def readiness():
            try:return json.loads(ready_path.read_text())
            except (FileNotFoundError,json.JSONDecodeError):return None
        ready=wait(readiness,'independent executor readiness',seconds=10)
        assert ready['Version']==1 and ready['EnvironmentID']=='dogfood-tests'
        assert int(subprocess.check_output(['systemctl','--user','show',executor_unit,'-p','MainPID','--value'],text=True))==ready['PID']
        executor_pidfd=os.pidfd_open(ready['PID'])
        job_cfg=run/'jobs.json';job_cfg.write_text(json.dumps({'Version':1,'EnvironmentID':'dogfood-tests','TLSAddress':ready['TLSAddress'],'TLSServerName':'executor.test','CAFile':str(cert),'Jobs':['repo-race-tests']}));job_cfg.chmod(0o600)
        env['UNREAL_AGENT_EXECUTOR_TOKEN']=token;env['UNREAL_AGENT_JOB_CONFIG']=str(job_cfg)
        client_env={k:v for k,v in env.items() if k not in ('UNREAL_AGENT_EXECUTOR_TOKEN','UNREAL_AGENT_JOB_CONFIG')}
        def latest_operation():
            path=state/(sid+'.session.jsonl')
            if not path.exists():return None
            raw=path.read_bytes();found=[]
            def visit(v):
                if isinstance(v,dict):
                    if v.get('Type')=='remote_job' and v.get('State',{}).get('Plan',{}).get('Type')=='durable_executor_job':found.append(v)
                    for item in v.values():visit(item)
                elif isinstance(v,list):
                    for item in v:visit(item)
            for line in raw[:raw.rfind(b'\n')+1].splitlines():visit(json.loads(line))
            return found[-1] if found else None
        def checkpoint():
            op=latest_operation()
            return op.get('State',{}).get('Handle',{}) if op else {}
        def worker_for(owner):
            children=set();tasks=list(pathlib.Path('/proc/'+str(owner.pid)+'/task').iterdir());assert 0<len(tasks)<=256
            for task in tasks:
                try:children.update((task/'children').read_text().split())
                except FileNotFoundError:pass
            assert 0<len(children)<=16
            lease=state/(sid+'.session.lock');st=lease.stat();identity=(st.st_dev,st.st_ino);holders=[]
            for child in children:
                try:fds=list(pathlib.Path('/proc/'+child+'/fd').iterdir())
                except FileNotFoundError:continue
                assert len(fds)<=512
                for fd in fds:
                    try:st=fd.stat()
                    except FileNotFoundError:continue
                    if (st.st_dev,st.st_ino)==identity:holders.append(int(child));break
            assert len(holders)==1,holders
            with lease.open('r+') as probe:
                try:fcntl.flock(probe,fcntl.LOCK_EX|fcntl.LOCK_NB)
                except BlockingIOError:pass
                else:raise AssertionError('worker lease not held')
            return holders[0]
        def go_test_child():
            if not (D/'job-shell-pid').exists():return None
            pid=int((D/'job-shell-pid').read_text());children=set()
            for task in pathlib.Path('/proc/'+str(pid)+'/task').iterdir():
                try:children.update((task/'children').read_text().split())
                except FileNotFoundError:pass
            for child in children:
                try:args=(pathlib.Path('/proc')/child/'cmdline').read_bytes().split(b'\0')
                except FileNotFoundError:continue
                if b'test' in args and b'-race' in args and b'-count=1' in args:return int(child)
            return None
'''
SCENARIO=r'''
        snap(a,'01-before-submit')
        text(a,'Run the trusted repo-race-tests job and report its actual result.',True)
        test_pid=wait(go_test_child,'real uncached Go race command running',seconds=15)
        test_pidfd=os.pidfd_open(test_pid)
        wait(lambda:checkpoint().get('Offset',0)>0,'committed output checkpoint',seconds=15)
        old_op=latest_operation();original_id=old_op['ID'];old_cp=checkpoint();old_handle=old_cp['Handle'];offset_before=old_cp['Offset']
        assert old_op['Status'] not in ('completed','failed','canceled')
        assert len((D/'job-launches').read_text().splitlines())==1
        snap(a,'02-tests-running-before-detach')
        old_identity=identity;old_worker=worker_for(host);worker_pidfd=os.pidfd_open(old_worker)
        detach(a)
        assert not select.select([test_pidfd],[],[],0)[0] and not select.select([executor_pidfd],[],[],0)[0]
        signal.pidfd_send_signal(worker_pidfd,signal.SIGKILL)
        wait(lambda:bool(select.select([worker_pidfd],[],[],0)[0]),'owned worker pidfd exit')
        old_host_pid=host.pid;old_host_exit=host.wait(timeout=10);assert old_host_exit!=0
        assert not select.select([test_pidfd],[],[],0)[0] and not select.select([executor_pidfd],[],[],0)[0]
        assert not back_endpoint.exists() and len((D/'job-launches').read_text().splitlines())==1
        host=subprocess.Popen(host_command+['-base-url',f'http://127.0.0.1:{server.server_port}'],env=env,stdout=(run/'replacement-host-stdout.txt').open('w'),stderr=(run/'replacement-host-stderr.txt').open('w'))
        wait(back_endpoint.exists,'fresh host endpoint')
        b=launch('frontend-b');new_identity=assert_connection_identity(b)
        assert new_identity[0]!=old_identity[0] and new_identity[2]!=old_host_pid
        wait(lambda:checkpoint().get('Handle')==old_handle,'same executor handle reattached')
        assert latest_operation()['ID']==original_id and checkpoint()['Offset']>=offset_before
        snap(b,'03-new-runtime-reattached-real-tests')
        dog_result={'recovery':'running','operation_id':original_id,'handle':old_handle,'offset_before':offset_before,'old_worker_pid':old_worker,'old_host_pid':old_host_pid,'old_host_exit':old_host_exit,'new_host_pid':host.pid,'old_incarnation':old_identity[0],'new_incarnation':new_identity[0],'executor_pid':ready['PID'],'test_command_pid':test_pid,'test_command_survived_runtime_death':True,'job_launches':1}
        write('dogfood-result.json',dog_result)
        def terminal():
            op=latest_operation()
            return op if op and op['Status'] in ('completed','failed','canceled') else None
        final=wait(terminal,'real test job terminal reconciliation',seconds=1200)
        receipt=json.loads((D/'job-result.json').read_text())
        assert final['ID']==original_id and checkpoint()['Handle']==old_handle
        assert checkpoint()['Offset']>=offset_before and len((D/'job-launches').read_text().splitlines())==1
        expected='DOGFOOD_TESTS_PASSED' if receipt['job_exit']==0 else 'DOGFOOD_TESTS_FAILED'
        wait(lambda:len(calls)==2 and expected in screen(b),'actual terminal test outcome visible',seconds=15)
        assert (final['Status']=='completed')==(receipt['job_exit']==0)
        records=list((run/'executor').glob('*.json'));assert len(records)==1
        reservation=json.loads(records[0].read_text());assert reservation['Handle']==old_handle and reservation['ExitCode']==receipt['job_exit']
        canonical=(state/(sid+'.session.jsonl')).read_text();assert token not in canonical and token not in json.dumps(frames)
        assert ready['TLSAddress'] not in canonical and str(cert) not in canonical
        snap(b,'04-real-test-outcome')
        keys(b,'C-c');join_front(b)
        host.send_signal(signal.SIGINT);assert host.wait(timeout=10)==0
        wait(lambda:not back_endpoint.exists(),'host endpoint removed')
        dog_result.update({'recovery':'PASS','test_result':'PASS' if receipt['job_exit']==0 else 'FAIL','root_test_exit':receipt['root_exit'],'tui_test_exit':receipt['tui_exit'],'job_exit':receipt['job_exit'],'operation_status':final['Status'],'offset_after':checkpoint()['Offset'],'provider_requests':len(calls),'credentials_absent':True,'host_actual_wait_zero':True})
        write('dogfood-result.json',dog_result)
        success=True
'''
CLEANUP=r'''
        if executor_unit is not None:
            attempt('executor exact unit stop/join',lambda:subprocess.run(['systemctl','--user','stop',executor_unit],check=True,capture_output=True,text=True,timeout=25))
            unit_state=subprocess.check_output(['systemctl','--user','show',executor_unit,'-p','ActiveState','-p','SubState','-p','MainPID','-p','Result','-p','ExecMainStatus'],text=True)
            (D/'executor-unit.final').write_text(unit_state)
            drained=not pathlib.Path('/sys/fs/cgroup'+executor_cgroup+'/cgroup.procs').exists()
            (D/'executor-drain.json').write_text(json.dumps({'unit':executor_unit,'cgroup':executor_cgroup,'exact_cgroup_absent':drained})+'\n')
            if not drained or 'MainPID=0' not in unit_state or 'ExecMainStatus=0' not in unit_state:cleanup_errors.append('executor join/drain unconfirmed')
        for fd in (executor_pidfd,worker_pidfd,test_pidfd):
            if fd is not None:os.close(fd)
'''
source=(REPO/'.claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py').read_text()
def replace(old,new):
 global source
 assert source.count(old)==1,old
 source=source.replace(old,new,1)
replace("    runner, tui = repo / 'bin/unreal-agent-runner', repo / 'bin/unreal-agent-tui'","    runner,tui=pathlib.Path(I['unreal-agent-runner']['path']),pathlib.Path(I['unreal-agent-tui']['path'])")
a=source.index('    env = os.environ |');b=source.index('    started =',a)
source=source[:a]+"    env={'PATH':os.environ['PATH'],'TERM':'xterm-256color','LANG':'C.UTF-8','HOME':str(run/'home'),'XDG_STATE_HOME':str(state),'XDG_CONFIG_HOME':str(run/'config'),'XDG_RUNTIME_DIR':str(run/'back'),'OPENAI_API_KEY':'fake','UNREAL_HARNESS_LLM_API_KEY':'fake'}\n"+source[b:]
replace('    proof_deadline = started + 48','    proof_deadline = started + 1450')
replace('    success = False','    success = False\n'+SETUP)
a=source.index('    class Model(');b=source.index('    # A transparent owned relay',a);source=source[:a]+MODEL+'\n'+source[b:]
replace("    def launch(label):\n","    def launch(label):\n        minimum_frame_index=len(frames)\n")
replace("        wait(lambda: 'Unreal Agent · attached ·' in screen(front), 'frontend ' + label + ' attached')","        wait(lambda: 'Ctrl+C detach' in screen(front) and any(f['event'].get('Type')=='snapshot' for f in frames[minimum_frame_index:]), 'frontend '+label+' fresh snapshot')")
replace("        assert len(calls) == (1 if front['directory'].name == 'frontend-a' else 2)","        assert len(calls)==1")
replace("        server = ThreadingHTTPServer(('127.0.0.1', 0), Model)",PREPARE+"\n        server = ThreadingHTTPServer(('127.0.0.1', 0), Model)")
replace('            env=env, stdout=(run / \'tmux-stdout.txt\')','            env=client_env, stdout=(run / \'tmux-stdout.txt\')')
a=source.index("        text(a, 'LIFECYCLE_MODEL_BLOCKED', True)");b=source.index('    except BaseException:',a);source=source[:a]+SCENARIO+'\n'+source[b:]
replace("        write('provider-calls.json', calls)",CLEANUP+"\n        write('provider-calls.json', calls)")
replace("            'no_late_tool': not (workspace / 'late-tool').exists(),","            'one_test_job_launch': (D/'job-launches').exists() and len((D/'job-launches').read_text().splitlines())==1,")
replace("            'sentinel_exactly_once': (workspace / 'sentinel').exists() and (workspace / 'sentinel').read_text() == 'x',","            'recovery_success': dog_result.get('recovery')=='PASS',")
replace("print('PASS: model/Bash frontend replacement, canonical abort/shutdown, host wait0, offline reconciliation, exact TTY restoration and owned joins; ' + str(evidence))","print('PASS: real test job recovery, private frontend/runtime replacement, actual joins and exact TTY; '+str(evidence))")
(D/'derived-driver.py').write_text(source)
namespace={'__name__':'dogfood_lifecycle','__file__':str(REPO/'.claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py'),'D':D,'ROOT':ROOT,'I':I}
exec(compile(source,str(D/'derived-driver.py'),'exec'),namespace)
sys.argv=[str(D/'derived-driver.py'),str(REPO),str(ROOT)]
namespace['main']()

"""Owned real-tmux lifecycle proof (not a retained-background-agent proof).

Usage: python3 -I durable_lifecycle.py REPO EXISTING_PRIVATE_SHORT_RUN_DIRECTORY
Run under a bounded, named user systemd unit; inspect its cgroup after stop.
This script never builds/installs binaries, opens another session, or uses the
user's tmux server. Success requires canonical outcomes AND actual owner joins.
The first remote HTTP handler deliberately stays blocked until fixture cleanup:
client transport cancellation is NOT evidence about remote provider billing.
"""
import hashlib
import json
import os
import pathlib
import select
import shlex
import signal
import socket
import subprocess
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# This wrapper owns and waits for the frontend child; tmux owns the wrapper.
# pidfds below observe the exact wrapper identity obtained from its owned pane.
PANE_WRAPPER = r'''
import json, os, pathlib, signal, subprocess, sys
root = pathlib.Path(sys.argv[1])
command = json.loads(sys.argv[2])
before = subprocess.check_output(['stty', '-g'], text=True)
(root / 'tty-before.txt').write_text(before)
p = None
forced = False
def terminate(signum, frame):
    global forced
    forced = True
    if p is not None and p.poll() is None:
        p.send_signal(signal.SIGINT)
signal.signal(signal.SIGTERM, terminate)
try:
    with (root / 'stderr.txt').open('w') as err:
        p = subprocess.Popen(command, stderr=err)
        (root / 'child.json').write_text(json.dumps({'pid': p.pid, 'wrapper': os.getpid()}))
        code = p.wait()
finally:
    after = subprocess.check_output(['stty', '-g'], text=True)
    (root / 'tty-after.txt').write_text(after)
    (root / 'joined.json').write_text(json.dumps({
        'returncode': p.returncode if p is not None else None,
        'child_waited': p is not None and p.returncode is not None,
        'tty_exact': before == after, 'forced': forced}))
'''


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    repo, root = (pathlib.Path(x).resolve() for x in sys.argv[1:])
    assert root.is_dir() and root.stat().st_mode & 0o7777 == 0o700
    assert root.stat().st_uid == os.getuid()
    os.umask(0o077)
    os.environ.pop('TMUX', None)
    os.environ['TMUX_TMPDIR'] = str(root)
    # Exclusive subdirectory rejects accidental reuse of an earlier proof.
    run = root / 'lifecycle'
    run.mkdir(mode=0o700)
    for name in ('state', 'workspace', 'clients', 'front', 'back', 'evidence', 'config', 'home'):
        (run / name).mkdir(mode=0o700)
    evidence = run / 'evidence'
    state, workspace = run / 'state', run / 'workspace'
    sid = 'lifecycle-' + hashlib.sha256(str(root).encode()).hexdigest()[:12]
    endpoint_name = hashlib.sha256((str(state) + '\0' + sid).encode()).hexdigest() + '.sock'
    front_endpoint, back_endpoint = run / 'front' / endpoint_name, run / 'back' / endpoint_name
    assert max(len(str(front_endpoint)), len(str(back_endpoint))) < 104, 'use a shorter private run directory'
    tmux_socket = root / 'lifecycle-tmux.sock'
    runner,tui=pathlib.Path(I['unreal-agent-runner']['path']),pathlib.Path(I['unreal-agent-tui']['path'])
    command = [str(tui), 'attach', '-runtime-directory', str(run / 'front'),
               '-session-directory', str(state), '-session', sid,
               '-client-state-directory', str(run / 'clients')]
    host_command = [str(runner), 'host', '-runtime-directory', str(run / 'back'),
                    '-session-directory', str(state), '-session', sid, '-workspace', str(workspace),
                    '-provider', 'openai', '-model', 'fake']
    env={'PATH':os.environ['PATH'],'TERM':'xterm-256color','LANG':'C.UTF-8','HOME':str(run/'home'),'XDG_STATE_HOME':str(state),'XDG_CONFIG_HOME':str(run/'config'),'XDG_RUNTIME_DIR':str(run/'back'),'OPENAI_API_KEY':'fake','UNREAL_HARNESS_LLM_API_KEY':'fake'}
    started = time.monotonic()
    proof_deadline = started + 1450  # leave bounded cleanup time within the enclosing unit
    cleanup_gate = threading.Event()
    proxy_stop = threading.Event()
    model_started = threading.Event()
    calls, handler_threads, proxy_threads, sockets, frames, frontends, errors = [], [], [], [], [], [], []
    lock = threading.Lock()
    host = tmux_server = provider = acceptor = server = listener = None
    success = False

    executor_unit=None
    executor_cgroup=None
    executor_pidfd=None
    worker_pidfd=None
    test_pidfd=None
    dog_result={}

    cleanup_errors = []
    outcomes = []

    def write(name, value):
        (evidence / name).write_text(json.dumps(value, indent=2) + '\n')

    def wait(fn, label, seconds=7, cleanup=False):
        end = time.monotonic() + seconds
        if not cleanup:
            end = min(end, proof_deadline)
        while time.monotonic() < end:
            value = fn()
            if value:
                return value
            time.sleep(.035)
        raise AssertionError('deadline: ' + label)

    def tmux(*args, check=True):
        return subprocess.run(['tmux', '-S', str(tmux_socket), *args], env=env,
                              capture_output=True, text=True, check=check, timeout=2)

    def screen(front):
        return tmux('capture-pane', '-p', '-t', front['session'], check=False).stdout

    def snap(front, name):
        text = screen(front)
        (evidence / (name + '.txt')).write_text(text)
        return text

    def keys(front, *args):
        tmux('send-keys', '-t', front['session'], *args)

    def text(front, value, submit=False):
        tmux('send-keys', '-t', front['session'], '-l', value)
        if submit:
            keys(front, 'Enter')

    def canonical_items():
        path = state / (sid + '.session.jsonl')
        if not path.exists():
            return []
        data = path.read_bytes()
        # Only newline-committed records; never parse a concurrent partial tail.
        records = [json.loads(line) for line in data[:data.rfind(b'\n') + 1].splitlines()]
        return [r['data']['Item'] for r in records if r['type'] == 'item']

    def controls():
        files = list((run / 'clients').glob('*.json'))
        if not files:
            return []
        assert len(files) == 1
        saved = json.loads(files[0].read_text())
        assert saved['Version'] == 2
        return saved.get('Controls', [])

    def outcome(control, mode, phase):
        items = canonical_items()
        intents = [i for i in items if i['Kind'] == 'input' and i['Data'].get('ID') == control['ID']]
        assert len(intents) <= 1, 'duplicate canonical control input'
        if not intents:
            return None
        assert intents[0]['Data'] == control['Input'], 'original saved control changed on wire'
        for item in items:
            if item['Kind'] != 'input':
                continue
            payload = item['Data'].get('Payload', {})
            if not isinstance(payload, dict) or payload.get('Mode') != mode:
                continue
            result = payload['Parameters']
            if result.get('InputID') != control['ID']:
                continue
            if mode == 'foreground_abort_finished':
                assert result['TargetTurnID'] == control['TargetTurnID']
                complete = result['Status'] == phase
            else:
                assert result['Scope'] == control['Scope']
                complete = result['Phase'] == phase
            if complete:
                assert not result.get('Error'), result
                return {'control': control, 'canonical_item': item}
        return None

    def abort(front, number):
        old = len(controls())
        text(front, '/abort', True)
        control = wait(lambda: controls()[-1] if len(controls()) == old + 1 else None,
                       'saved abort identity')
        assert control['TargetTurnID'] and control['Scope']
        result = wait(lambda: outcome(control, 'foreground_abort_finished', 'completed'),
                      'canonical foreground abort completed')
        outcomes.append(result)
        wait(lambda: control['ID'] in screen(front) and 'completed' in screen(front),
             'frontend canonical abort outcome')
        snap(front, number + '-abort-completed')
        return control

    def launch(label):
        minimum_frame_index=len(frames)
        directory = run / label
        directory.mkdir(mode=0o700)
        front = {'session': 'ul-' + sid[-12:] + '-' + label, 'directory': directory,
                 'pidfd': None, 'joined': False}
        frontends.append(front)
        wrapped = [sys.executable, '-I', '-c', PANE_WRAPPER, str(directory), json.dumps(command)]
        tmux('new-session', '-d', '-s', front['session'], '-x', '160', '-y', '50',
             '-c', str(workspace), 'exec ' + shlex.join(wrapped))
        pane_pid = int(tmux('display-message', '-p', '-t', front['session'], '#{pane_pid}').stdout)
        front['pane_pid'] = pane_pid
        front['pidfd'] = os.pidfd_open(pane_pid)
        wait(lambda: 'Ctrl+C detach' in screen(front) and any(f['event'].get('Type')=='snapshot' for f in frames[minimum_frame_index:]), 'frontend '+label+' fresh snapshot')
        hello = wait(lambda: next((f for f in reversed(frames)
                                  if f['event'].get('Type') == 'snapshot'), None), 'snapshot frame')
        front['snapshot_connection'] = hello['connection']
        return front

    def join_front(front, cleanup=False):
        joined = front['directory'] / 'joined.json'
        wait(joined.exists, 'frontend child wait receipt', seconds=5, cleanup=cleanup)
        receipt = json.loads(joined.read_text())
        assert receipt['child_waited'] and receipt['returncode'] == 0 and receipt['tty_exact']
        assert not receipt['forced'], 'forced frontend cleanup is not successful detach proof'
        wait(lambda: bool(select.select([front['pidfd']], [], [], 0)[0]),
             'exact pane wrapper process exit', seconds=3, cleanup=cleanup)
        front['joined'] = True
        write(front['directory'].name + '-tty-join.json', receipt | {
            'pane_pid': front['pane_pid'], 'wrapper_exit_pidfd_observed': True})

    def detach(front):
        keys(front, 'C-c')
        join_front(front)
        assert host.poll() is None, 'detach terminated host'
        assert len(calls)==1

    def assert_connection_identity(front, expected=None):
        connection = front['snapshot_connection']
        events = [f['event'] for f in frames if f['connection'] == connection]
        hello = next(e for e in events if e['Type'] == 'hello')
        snapshot = next(e for e in events if e['Type'] == 'snapshot')
        identity = (hello['Incarnation'], snapshot['Status']['Generation'], hello['HostPID'])
        assert identity[0] and identity[1] > 0 and identity[2] == host.pid
        if expected is not None:
            assert identity == expected, 'host incarnation/generation changed on detach'
        write(front['directory'].name + '-identity.json', {'hello': hello, 'snapshot': snapshot})
        return identity


    class Model(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_POST(self):
            handler_threads.append(threading.current_thread())
            raw=self.rfile.read(int(self.headers['Content-Length']))
            body=json.loads(raw);calls.append(body)
            number=len(calls)
            if number==1:
                output=[{'type':'function_call','id':'dogfood-tests','call_id':'dogfood-tests','name':'RunTrustedJob','arguments':'{"job":"repo-race-tests"}'}]
            elif number==2:
                op=latest_operation();assert op and op['Status'] in ('completed','failed')
                receipt=json.loads((D/'job-result.json').read_text())
                label='DOGFOOD_TESTS_PASSED' if receipt['job_exit']==0 else 'DOGFOOD_TESTS_FAILED'
                output=[{'type':'message','id':'dogfood-outcome','role':'assistant','content':[{'type':'output_text','text':label+' root='+str(receipt['root_exit'])+' tui='+str(receipt['tui_exit'])}]}]
            else:raise AssertionError('duplicate model continuation '+str(number))
            event={'type':'response.completed','response':{'id':'dogfood-'+str(number),'status':'completed','output':output,'usage':{'input_tokens':1,'output_tokens':1}}}
            self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
            self.wfile.write(('data: '+json.dumps(event)+'\n\n').encode())

    # A transparent owned relay records *actual frontend* hello/status identities
    # without taking a competing attach lease or issuing any control itself.
    def relay(client, index):
        backend = socket.socket(socket.AF_UNIX)
        with lock:
            sockets.extend([client, backend])
        try:
            backend.settimeout(2)
            backend.connect(str(back_endpoint))
            backend.setblocking(False)
            client.setblocking(False)
            buffers = {client: bytearray(), backend: bytearray()}
            wire = bytearray()
            while not proxy_stop.is_set():
                readable, writable, _ = select.select([client, backend],
                    [s for s in (client, backend) if buffers[s]], [], .05)
                for source in readable:
                    try:
                        data = source.recv(65536)
                    except BlockingIOError:
                        continue
                    if not data:
                        return
                    target = backend if source is client else client
                    buffers[target].extend(data)
                    assert len(buffers[target]) <= 8 << 20, 'relay queue exceeded bound'
                    if source is backend:
                        wire.extend(data)
                        assert len(wire) <= 1 << 20, 'relay frame exceeded bound'
                        while b'\n' in wire:
                            line, _, remaining = wire.partition(b'\n')
                            wire[:] = remaining
                            frames.append({'connection': index, 'event': json.loads(line)})
                for target in writable:
                    try:
                        sent = target.send(buffers[target])
                        del buffers[target][:sent]
                    except BlockingIOError:
                        pass
        except (BrokenPipeError, ConnectionResetError):
            pass
        except OSError as exc:
            if not proxy_stop.is_set():
                errors.append('relay: ' + repr(exc))
        except BaseException as exc:
            errors.append('relay: ' + repr(exc))
        finally:
            client.close()
            backend.close()

    def accept():
        while not proxy_stop.is_set():
            try:
                client, _ = listener.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            thread = threading.Thread(target=relay, args=(client, len(proxy_threads)), name='lifecycle-relay')
            proxy_threads.append(thread)
            thread.start()

    def attempt(label, fn):
        try:
            fn()
        except BaseException:
            cleanup_errors.append(label + ': ' + traceback.format_exc())

    try:

        import base64,secrets,fcntl
        job_home=ROOT/'job-home';job_home.mkdir(mode=0o700)
        job_tmp=ROOT/'jt';job_tmp.mkdir(mode=0o700)
        token=secrets.token_urlsafe(40)
        cert,key=run/'executor-cert.pem',run/'executor-key.pem'
        subprocess.run(['openssl','req','-x509','-newkey','ed25519','-nodes','-days','1','-subj','/CN=executor.test','-addext','subjectAltName=DNS:executor.test','-out',str(cert),'-keyout',str(key)],check=True,env=env,stdout=subprocess.DEVNULL,stderr=(run/'cert-stderr.txt').open('w'))
        cert.chmod(0o600);key.chmod(0o600)
        job_env=['PATH='+I['goroot']+'/bin:/usr/bin:/bin','GOROOT='+I['goroot'],'HOME='+str(job_home),'TMPDIR='+str(job_tmp),'GOCACHE='+I['gocache'],'GOMODCACHE='+I['gomodcache'],'GOPATH='+str(job_home/'go'),'GOTOOLCHAIN=local','GOPROXY=off','GOSUMDB=off','GOFLAGS=-p=2','LANG=C.UTF-8']
        cfg=run/'executor.json';cfg.write_text(json.dumps({'Version':1,'Directory':str(run/'executor'),'EnvironmentID':'dogfood-tests','ControllerIDs':['session-'+hashlib.sha256(sid.encode()).hexdigest()[:32]],'TLSAddress':'127.0.0.1:0','CertFile':str(cert),'KeyFile':str(key),'Jobs':{'repo-race-tests':{'Path':'/usr/bin/zsh','Args':[str(D/'job.zsh'),str(D)],'Dir':I['snapshot'],'Env':job_env}}}));cfg.chmod(0o600)
        executor_unit='unreal-agent-dogfood-executor-'+sid[-12:]+'.service'
        executor_start=D/'executor.zsh'
        executor_start.write_text('exec '+shlex.join([str(runner),'job-executor','--config',str(cfg)])+' >'+shlex.quote(str(D/'executor-ready.json'))+' 2>'+shlex.quote(str(D/'executor-stderr.txt'))+'\n');executor_start.chmod(0o700)
        exec_env=os.environ.copy();exec_env['UNREAL_AGENT_EXECUTOR_TOKEN']=token
        subprocess.run(['systemd-run','--user','--unit',executor_unit,'--remain-after-exit','--setenv=UNREAL_AGENT_EXECUTOR_TOKEN','--property=RuntimeMaxSec=22min','--property=TimeoutStopSec=15s','--property=KillMode=control-group','--','/usr/bin/zsh',str(executor_start)],env=exec_env,check=True,capture_output=True,text=True)
        executor_cgroup=subprocess.check_output(['systemctl','--user','show',executor_unit,'-p','ControlGroup','--value'],text=True).strip()
        (D/'executor-unit.json').write_text(json.dumps({'unit':executor_unit,'cgroup':executor_cgroup})+'\n')
        ready_path=D/'executor-ready.json'
        def readiness():
            try:return json.loads(ready_path.read_text())
            except (FileNotFoundError,json.JSONDecodeError):return None
        ready=wait(readiness,'independent executor readiness',seconds=10)
        assert ready['Version']==1 and ready['EnvironmentID']=='dogfood-tests'
        assert int(subprocess.check_output(['systemctl','--user','show',executor_unit,'-p','MainPID','--value'],text=True))==ready['PID']
        executor_pidfd=os.pidfd_open(ready['PID'])
        job_cfg=run/'jobs.json';job_cfg.write_text(json.dumps({'Version':1,'EnvironmentID':'dogfood-tests','TLSAddress':ready['TLSAddress'],'TLSServerName':'executor.test','CAFile':str(cert),'Jobs':['repo-race-tests']}));job_cfg.chmod(0o600)
        env['UNREAL_AGENT_EXECUTOR_TOKEN']=token;env['UNREAL_AGENT_JOB_CONFIG']=str(job_cfg)
        client_env={k:v for k,v in env.items() if k not in ('UNREAL_AGENT_EXECUTOR_TOKEN','UNREAL_AGENT_JOB_CONFIG')}
        def latest_operation():
            path=state/(sid+'.session.jsonl')
            if not path.exists():return None
            raw=path.read_bytes();found=[]
            def visit(v):
                if isinstance(v,dict):
                    if v.get('Type')=='remote_job' and v.get('State',{}).get('Plan',{}).get('Type')=='durable_executor_job':found.append(v)
                    for item in v.values():visit(item)
                elif isinstance(v,list):
                    for item in v:visit(item)
            for line in raw[:raw.rfind(b'\n')+1].splitlines():visit(json.loads(line))
            return found[-1] if found else None
        def checkpoint():
            op=latest_operation()
            return op.get('State',{}).get('Handle',{}) if op else {}
        def worker_for(owner):
            children=set();tasks=list(pathlib.Path('/proc/'+str(owner.pid)+'/task').iterdir());assert 0<len(tasks)<=256
            for task in tasks:
                try:children.update((task/'children').read_text().split())
                except FileNotFoundError:pass
            assert 0<len(children)<=16
            lease=state/(sid+'.session.lock');st=lease.stat();identity=(st.st_dev,st.st_ino);holders=[]
            for child in children:
                try:fds=list(pathlib.Path('/proc/'+child+'/fd').iterdir())
                except FileNotFoundError:continue
                assert len(fds)<=512
                for fd in fds:
                    try:st=fd.stat()
                    except FileNotFoundError:continue
                    if (st.st_dev,st.st_ino)==identity:holders.append(int(child));break
            assert len(holders)==1,holders
            with lease.open('r+') as probe:
                try:fcntl.flock(probe,fcntl.LOCK_EX|fcntl.LOCK_NB)
                except BlockingIOError:pass
                else:raise AssertionError('worker lease not held')
            return holders[0]
        def go_test_child():
            if not (D/'job-shell-pid').exists():return None
            pid=int((D/'job-shell-pid').read_text());children=set()
            for task in pathlib.Path('/proc/'+str(pid)+'/task').iterdir():
                try:children.update((task/'children').read_text().split())
                except FileNotFoundError:pass
            for child in children:
                try:args=(pathlib.Path('/proc')/child/'cmdline').read_bytes().split(b'\0')
                except FileNotFoundError:continue
                if b'test' in args and b'-race' in args and b'-count=1' in args:return int(child)
            return None

        server = ThreadingHTTPServer(('127.0.0.1', 0), Model)
        server.daemon_threads = False
        provider = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .05}, name='lifecycle-http')
        provider.start()
        listener = socket.socket(socket.AF_UNIX)
        listener.bind(str(front_endpoint))
        front_endpoint.chmod(0o600)  # The real SDK requires a private 0600 socket.
        listener.listen(4)
        listener.settimeout(.1)
        acceptor = threading.Thread(target=accept, name='lifecycle-accept')
        acceptor.start()
        tmux_server = subprocess.Popen(['tmux', '-D', '-S', str(tmux_socket), '-f', '/dev/null'],
            env=client_env, stdout=(run / 'tmux-stdout.txt').open('w'), stderr=(run / 'tmux-stderr.txt').open('w'))
        wait(lambda: tmux_socket.exists(), 'owned foreground tmux server')
        host = subprocess.Popen(host_command + ['-base-url', f'http://127.0.0.1:{server.server_port}'],
            env=env, stdout=(run / 'host-stdout.txt').open('w'), stderr=(run / 'host-stderr.txt').open('w'))
        wait(back_endpoint.exists, 'host endpoint ready')
        a = launch('frontend-a')
        identity = assert_connection_identity(a)

        snap(a,'01-before-submit')
        text(a,'Run the trusted repo-race-tests job and report its actual result.',True)
        test_pid=wait(go_test_child,'real uncached Go race command running',seconds=15)
        test_pidfd=os.pidfd_open(test_pid)
        wait(lambda:checkpoint().get('Offset',0)>0,'committed output checkpoint',seconds=15)
        old_op=latest_operation();original_id=old_op['ID'];old_cp=checkpoint();old_handle=old_cp['Handle'];offset_before=old_cp['Offset']
        assert old_op['Status'] not in ('completed','failed','canceled')
        assert len((D/'job-launches').read_text().splitlines())==1
        snap(a,'02-tests-running-before-detach')
        old_identity=identity;old_worker=worker_for(host);worker_pidfd=os.pidfd_open(old_worker)
        detach(a)
        assert not select.select([test_pidfd],[],[],0)[0] and not select.select([executor_pidfd],[],[],0)[0]
        signal.pidfd_send_signal(worker_pidfd,signal.SIGKILL)
        wait(lambda:bool(select.select([worker_pidfd],[],[],0)[0]),'owned worker pidfd exit')
        old_host_pid=host.pid;old_host_exit=host.wait(timeout=10);assert old_host_exit!=0
        assert not select.select([test_pidfd],[],[],0)[0] and not select.select([executor_pidfd],[],[],0)[0]
        assert not back_endpoint.exists() and len((D/'job-launches').read_text().splitlines())==1
        host=subprocess.Popen(host_command+['-base-url',f'http://127.0.0.1:{server.server_port}'],env=env,stdout=(run/'replacement-host-stdout.txt').open('w'),stderr=(run/'replacement-host-stderr.txt').open('w'))
        wait(back_endpoint.exists,'fresh host endpoint')
        b=launch('frontend-b');new_identity=assert_connection_identity(b)
        assert new_identity[0]!=old_identity[0] and new_identity[2]!=old_host_pid
        wait(lambda:checkpoint().get('Handle')==old_handle,'same executor handle reattached')
        assert latest_operation()['ID']==original_id and checkpoint()['Offset']>=offset_before
        snap(b,'03-new-runtime-reattached-real-tests')
        dog_result={'recovery':'running','operation_id':original_id,'handle':old_handle,'offset_before':offset_before,'old_worker_pid':old_worker,'old_host_pid':old_host_pid,'old_host_exit':old_host_exit,'new_host_pid':host.pid,'old_incarnation':old_identity[0],'new_incarnation':new_identity[0],'executor_pid':ready['PID'],'test_command_pid':test_pid,'test_command_survived_runtime_death':True,'job_launches':1}
        write('dogfood-result.json',dog_result)
        def terminal():
            op=latest_operation()
            return op if op and op['Status'] in ('completed','failed','canceled') else None
        final=wait(terminal,'real test job terminal reconciliation',seconds=1200)
        receipt=json.loads((D/'job-result.json').read_text())
        assert final['ID']==original_id and checkpoint()['Handle']==old_handle
        assert checkpoint()['Offset']>=offset_before and len((D/'job-launches').read_text().splitlines())==1
        expected='DOGFOOD_TESTS_PASSED' if receipt['job_exit']==0 else 'DOGFOOD_TESTS_FAILED'
        wait(lambda:len(calls)==2 and expected in screen(b),'actual terminal test outcome visible',seconds=15)
        assert (final['Status']=='completed')==(receipt['job_exit']==0)
        records=list((run/'executor').glob('*.json'));assert len(records)==1
        reservation=json.loads(records[0].read_text());assert reservation['Handle']==old_handle and reservation['ExitCode']==receipt['job_exit']
        canonical=(state/(sid+'.session.jsonl')).read_text();assert token not in canonical and token not in json.dumps(frames)
        assert ready['TLSAddress'] not in canonical and str(cert) not in canonical
        snap(b,'04-real-test-outcome')
        keys(b,'C-c');join_front(b)
        host.send_signal(signal.SIGINT);assert host.wait(timeout=10)==0
        wait(lambda:not back_endpoint.exists(),'host endpoint removed')
        dog_result.update({'recovery':'PASS','test_result':'PASS' if receipt['job_exit']==0 else 'FAIL','root_test_exit':receipt['root_exit'],'tui_test_exit':receipt['tui_exit'],'job_exit':receipt['job_exit'],'operation_status':final['Status'],'offset_after':checkpoint()['Offset'],'provider_requests':len(calls),'credentials_absent':True,'host_actual_wait_zero':True})
        write('dogfood-result.json',dog_result)
        success=True

    except BaseException:
        (evidence / 'failure.txt').write_text(traceback.format_exc())
        for front in frontends:
            attempt('failure screenshot', lambda front=front: snap(front, front['directory'].name + '-FAILURE'))
    finally:
        # Fixture release is not a runtime-abort proof; only the completed path
        # above asserts sentinel stability while the Bash gate is still closed.
        cleanup_gate.set()
        if not success:
            (workspace / 'bash-gate').touch()
        for front in frontends:
            if front['joined']:
                continue
            attempt('frontend Ctrl+C', lambda front=front: keys(front, 'C-c'))
            attempt('frontend join', lambda front=front: join_front(front, cleanup=True))
            if not front['joined'] and front['pidfd'] is not None:
                attempt('owned wrapper TERM', lambda front=front: signal.pidfd_send_signal(front['pidfd'], signal.SIGTERM))
                attempt('wrapper exit', lambda front=front: wait(
                    lambda: bool(select.select([front['pidfd']], [], [], 0)[0]), 'wrapper cleanup exit', 3, cleanup=True))
        if host is not None and host.poll() is None:
            attempt('host interrupt', lambda: host.send_signal(signal.SIGINT))
            attempt('host wait', lambda: host.wait(timeout=6))
        proxy_stop.set()
        if listener is not None:
            listener.close()
        if acceptor is not None:
            acceptor.join(2)
        for connection in sockets:
            attempt('relay socket close', connection.close)
        for thread in proxy_threads:
            thread.join(2)
        if server is not None:
            server.shutdown()
            # With daemon_threads=False, server_close joins all owned request
            # handlers. Release gate precedes this; no HTTP thread is abandoned.
            server.server_close()
        if provider is not None:
            provider.join(2)
        for thread in handler_threads:
            thread.join(2)
        if tmux_server is not None and tmux_server.poll() is None:
            attempt('tmux exit-empty', lambda: tmux('set-option', '-g', 'exit-empty', 'on'))
            attempt('tmux server wait', lambda: tmux_server.wait(timeout=3))
        for front in frontends:
            if front['pidfd'] is not None:
                os.close(front['pidfd'])

        if executor_unit is not None:
            attempt('executor exact unit stop/join',lambda:subprocess.run(['systemctl','--user','stop',executor_unit],check=True,capture_output=True,text=True,timeout=25))
            unit_state=subprocess.check_output(['systemctl','--user','show',executor_unit,'-p','ActiveState','-p','SubState','-p','MainPID','-p','Result','-p','ExecMainStatus'],text=True)
            (D/'executor-unit.final').write_text(unit_state)
            drained=not pathlib.Path('/sys/fs/cgroup'+executor_cgroup+'/cgroup.procs').exists()
            (D/'executor-drain.json').write_text(json.dumps({'unit':executor_unit,'cgroup':executor_cgroup,'exact_cgroup_absent':drained})+'\n')
            if not drained or 'MainPID=0' not in unit_state or 'ExecMainStatus=0' not in unit_state:cleanup_errors.append('executor join/drain unconfirmed')
        for fd in (executor_pidfd,worker_pidfd,test_pidfd):
            if fd is not None:os.close(fd)

        write('provider-calls.json', calls)
        write('frontend-frames.json', frames)
        write('outcomes.json', outcomes)
        write('cleanup-errors.json', cleanup_errors)
        cleanup = {
            'proof_completed': success,
            'host_joined_zero': host is not None and host.returncode == 0,
            'host_endpoint_gone': not back_endpoint.exists(),
            'frontends_waited_zero_and_tty_exact': bool(frontends) and all(f['joined'] for f in frontends),
            'relay_acceptor_joined': acceptor is not None and not acceptor.is_alive(),
            'relay_watchers_joined': all(not t.is_alive() for t in proxy_threads),
            'http_server_joined': provider is not None and not provider.is_alive(),
            'http_handlers_joined': all(not t.is_alive() for t in handler_threads),
            'tmux_server_waited_zero': tmux_server is not None and tmux_server.returncode == 0,
            'provider_calls_exactly_two': len(calls) == 2,
            'one_test_job_launch': (D/'job-launches').exists() and len((D/'job-launches').read_text().splitlines())==1,
            'recovery_success': dog_result.get('recovery')=='PASS',
            'no_fixture_errors': not errors and not cleanup_errors,
        }
        write('cleanup.json', cleanup)
        write('fixture-errors.json', errors)
    if not all(cleanup.values()):
        raise SystemExit('FAIL: owned lifecycle proof/cleanup incomplete; inspect ' + str(evidence))
    print('PASS: real test job recovery, private frontend/runtime replacement, actual joins and exact TTY; '+str(evidence))


if __name__ == '__main__':
    main()

from pathlib import Path
import hashlib,json,os,shlex,stat,subprocess,sys
repo,d,r=map(lambda x:Path(x).resolve(),sys.argv[1:]);os.chdir(repo)
snapshot=d/'snapshot';snapshot.mkdir(mode=0o700)
roots=['cmd','harness','internal','go.mod','go.sum','Makefile','docs/formal','AGENTS.md','README.md']
names=sorted(set(filter(None,subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z',*roots]).split(b'\0'))));manifest=[];total=0
for raw in names:
 name=os.fsdecode(raw);src=repo/name;st=src.lstat();assert stat.S_ISREG(st.st_mode),name
 assert st.st_size<=16<<20;total+=st.st_size;assert total<100<<20
 data=src.read_bytes();digest=hashlib.sha256(data).hexdigest();dst=snapshot/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);dst.chmod(stat.S_IMODE(st.st_mode));assert hashlib.sha256(dst.read_bytes()).hexdigest()==digest
 manifest.append(digest+'  '+name)
accepted='\n'.join(x for x in manifest if x.split('  ',1)[1] not in ('AGENTS.md','README.md'))+'\n'
assert hashlib.sha256(accepted.encode()).hexdigest()=='017f78bb07f654fbce153eba3132903995ee997e993d63e5db68996f237de212','source differs from validated installed pair: validate/build/reinstall before reusing this recipe'
for name in ['source.before.sha256','snapshot.manifest.sha256']:(d/name).write_text('\n'.join(manifest)+'\n')
i={'repo':str(repo),'snapshot':str(snapshot),'source_roots':roots,'source_files':len(manifest),'source_bytes':total,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'graph_blob':subprocess.check_output(['git','hash-object','harness/taskgraph/graph.go'],text=True).strip()}
for name in ['GOROOT','GOMODCACHE','GOCACHE']:i[name.lower()]=subprocess.check_output(['go','env',name],text=True).strip()
for name in ['unreal-agent-runner','unreal-agent-tui']:
 installed=Path.home()/'.local/bin'/name;assert installed.read_bytes()==(repo/'bin'/name).read_bytes();i[name]={'path':str(installed),'sha256':hashlib.sha256(installed.read_bytes()).hexdigest()}
base=repo/'.claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py';assert base.read_bytes()==(d/'lifecycle-base.py').read_bytes(),'lifecycle fixture changed: review transforms before reuse'
(d/'inputs.json').write_text(json.dumps(i,indent=2)+'\n');(d/'root').write_text(str(r)+'\n');(d/'preflight-home').mkdir(mode=0o700)
env=['/usr/bin/env','-i','PATH='+i['goroot']+'/bin:/usr/bin:/bin','HOME='+str(d/'preflight-home'),'GOCACHE='+i['gocache'],'GOMODCACHE='+i['gomodcache'],'GOTOOLCHAIN=local','GOPROXY=off','GOSUMDB=off','GOFLAGS=-p=2 -buildvcs=false',i['goroot']+'/bin/go']
s='#!/usr/bin/zsh\ncd '+shlex.quote(str(snapshot))+'\n'
for cmd,out in [(['list','./...'],'preflight.root'),(['-C','cmd/unreal-agent-tui','list','./...'],'preflight.tui')]:s+=shlex.join(env+cmd)+' >'+shlex.quote(str(d/out))+' 2>>'+shlex.quote(str(d/'preflight.stderr'))+' ||exit 91\n'
s+='python3 -I '+shlex.quote(str(d/'driver.py'))+' '+shlex.quote(str(d))+' >'+shlex.quote(str(d/'driver.log'))+' 2>&1\nrc=$?;print -r -- "$rc" >'+shlex.quote(str(d/'driver-exit-code'))+';exit $rc\n'
(d/'run.zsh').write_text(s)
print(json.dumps({'artifacts':str(d),'private_root':str(r),'source_files':len(manifest)}))

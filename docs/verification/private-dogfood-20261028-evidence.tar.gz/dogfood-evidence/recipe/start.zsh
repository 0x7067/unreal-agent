#!/usr/bin/zsh
set -eu
repo=${1:?Pass the absolute repository root}
seed=${0:A:h}
D=$(mktemp -d /tmp/unreal-agent-dogfood.XXXXXX)
R=$(mktemp -d /tmp/ud.XXXXXX)
cp "$seed/driver.py" "$seed/job.zsh" "$seed/lifecycle-base.py" "$D/"
python3 -I "$seed/prepare.py" "$repo" "$D" "$R"
U=unreal-agent-dogfood-ui-$(date -u +%Y%m%dT%H%M%SZ)-${D:t}.service
print -r -- "$U" >"$D/ui-unit"
systemd-run --user --unit "$U" --remain-after-exit --working-directory "$repo" --setenv PATH="$PATH" --setenv HOME="$HOME" --property RuntimeMaxSec=25min --property TimeoutStopSec=20s --property KillMode=control-group -- /usr/bin/zsh "$D/run.zsh"
systemctl --user show "$U" -p ControlGroup --value >"$D/ui-cgroup"
print -r -- "QUEUED (not PASS): artifacts=$D unit=$U"
print -r -- "Follow the runbook's join, validation and exact-unit-stop steps."

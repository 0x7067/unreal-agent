#!/usr/bin/zsh
setopt pipefail
umask 077
D=$1
printf '%s\n' $$ >>"$D/job-launches"
printf '%s\n' $$ >"$D/job-shell-pid"
go list ./... >"$D/packages.root.before"
a=$?
go -C cmd/unreal-agent-tui list ./... >"$D/packages.tui.before"
b=$?
if [[ $a != 0 || $b != 0 ]];then exit 90;fi
printf 'DOGFOOD_ROOT_BEGIN\n'
go test -race -count=1 ./... 2>&1 | tee "$D/root-tests.log"
root_rc=$pipestatus[1]
printf 'DOGFOOD_ROOT_EXIT=%s\nDOGFOOD_TUI_BEGIN\n' "$root_rc"
go -C cmd/unreal-agent-tui test -race -count=1 ./... 2>&1 | tee "$D/tui-tests.log"
tui_rc=$pipestatus[1]
printf 'DOGFOOD_TUI_EXIT=%s\n' "$tui_rc"
go list ./... >"$D/packages.root.after"
go -C cmd/unreal-agent-tui list ./... >"$D/packages.tui.after"
python3 - "$D" "$root_rc" "$tui_rc" <<'PY'
import json,os,sys,time
from pathlib import Path
p=Path(sys.argv[1]);r,t=map(int,sys.argv[2:]);out=p/'job-result.json.tmp';out.write_text(json.dumps({'root_exit':r,'tui_exit':t,'job_exit':0 if r==t==0 else 1,'finished_unix':time.time(),'uncached':True,'race_both_modules':True})+'\n');os.replace(out,p/'job-result.json')
PY
if [[ $root_rc == 0 && $tui_rc == 0 ]];then exit 0;else exit 1;fi

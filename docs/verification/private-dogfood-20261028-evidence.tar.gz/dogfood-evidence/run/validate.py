from pathlib import Path
import hashlib,json,os,re,subprocess,sys
p=Path(sys.argv[1]);i=json.loads((p/'inputs.json').read_text());repo=Path(i['repo']);r=Path((p/'root').read_text().strip());ev=r/'lifecycle/evidence'
result=json.loads((ev/'dogfood-result.json').read_text());cleanup=json.loads((ev/'cleanup.json').read_text());receipt=json.loads((p/'job-result.json').read_text())
assert result['recovery']=='PASS' and all(cleanup.values()),(result,cleanup)
assert (p/'driver-exit-code').read_text().strip()=='0'
assert result['root_test_exit']==receipt['root_exit'] and result['tui_test_exit']==receipt['tui_exit'] and result['job_exit']==receipt['job_exit']
packages={};counts={};failed=[];all_rows=[]
for module in ['root','tui']:
 before=(p/f'packages.{module}.before').read_text().splitlines();after=(p/f'packages.{module}.after').read_text().splitlines();preflight=(p/f'preflight.{module}').read_text().splitlines()
 assert before==after==preflight and len(before)==len(set(before))
 rows=[]
 for line in (p/f'{module}-tests.log').read_text().splitlines():
  m=re.match(r'^(ok|FAIL|\?)\s+(github\.com/unreallabsai/unreal-agent(?:/\S*)?)\s+(.*)$',line)
  if m:
   status,name,tail=m.groups();assert '(cached)' not in tail;rows.append((status,name,tail))
 assert len(rows)==len(before) and sorted(x[1] for x in rows)==sorted(before),(module,len(rows),len(before))
 counts[module]={'packages':len(before),'passing':sum(x[0]=='ok' for x in rows),'failed':sum(x[0]=='FAIL' for x in rows),'no_test_files':sum(x[0]=='?' for x in rows),'exit_code':receipt[module+'_exit']}
 assert (receipt[module+'_exit']==0)==(counts[module]['failed']==0)
 failed += [name for status,name,tail in rows if status=='FAIL'];all_rows+=rows;packages[module]=before
assert len(all_rows)==57 and len(set(x[1] for x in all_rows))==57
assert len(packages['root'])==52 and len(packages['tui'])==5
names=sorted(set(filter(None,subprocess.check_output(['git','-C',str(repo),'ls-files','--cached','--others','--exclude-standard','-z',*i['source_roots']]).split(b'\0'))));manifest=[]
for raw in names:
 name=os.fsdecode(raw);data=(repo/name).read_bytes();manifest.append(hashlib.sha256(data).hexdigest()+'  '+name)
current='\n'.join(manifest)+'\n';(p/'source.after.sha256').write_text(current);(p/'source.current.sha256').write_text(current)
assert current==(p/'source.before.sha256').read_text()==(p/'snapshot.manifest.sha256').read_text()
for row in manifest:
 digest,name=row.split('  ',1);assert hashlib.sha256((Path(i['snapshot'])/name).read_bytes()).hexdigest()==digest
assert len(manifest)==655
accepted='\n'.join(x for x in manifest if x.split('  ',1)[1] not in ('AGENTS.md','README.md'))+'\n'
assert hashlib.sha256(accepted.encode()).hexdigest()=='017f78bb07f654fbce153eba3132903995ee997e993d63e5db68996f237de212'
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==i['head']=='9c0abbe4a9aa003851ef0b3448b58af0a049c4a9'
assert subprocess.check_output(['git','-C',str(repo),'hash-object','harness/taskgraph/graph.go'],text=True).strip()==i['graph_blob']=='2315afc35788160fc81bf84657f2600bd61c9e86'
for name in ['unreal-agent-runner','unreal-agent-tui']:
 installed=Path(i[name]['path']);assert installed.read_bytes()==(repo/'bin'/name).read_bytes();assert hashlib.sha256(installed.read_bytes()).hexdigest()==i[name]['sha256']
assert len((p/'job-launches').read_text().splitlines())==1
records=list((r/'lifecycle/executor').glob('*.json'));assert len(records)==1
reservation=json.loads(records[0].read_text());assert reservation['Handle']==result['handle'] and reservation['ExitCode']==receipt['job_exit'];assert reservation['State']==('completed' if receipt['job_exit']==0 else 'failed')
assert result['offset_before']>0 and result['offset_after']>=result['offset_before'] and result['provider_requests']==2
assert not reservation['Truncated']
for name in ['frontend-a','frontend-b']:
 tty=json.loads((ev/(name+'-tty-join.json')).read_text());assert tty['returncode']==0 and tty['child_waited'] and tty['tty_exact'] and not tty['forced'] and tty['wrapper_exit_pidfd_observed']
unit_audits=[]
for artifact,kind in [(p,'exercise'),(Path((p/'rejected-setup-artifacts').read_text().strip()),'rejected-setup')]:
 for which in ['ui','executor']:
  if which=='ui':unit=(artifact/'ui-unit').read_text().strip();cg=(artifact/'ui-cgroup').read_text().strip()
  else:unit_info=json.loads((artifact/'executor-unit.json').read_text());unit,cg=unit_info['unit'],unit_info['cgroup']
  def show():
   raw=subprocess.check_output(['systemctl','--user','show',unit,'-p','LoadState','-p','ActiveState','-p','SubState','-p','MainPID','-p','Result','-p','ExecMainStatus'],text=True);return dict(line.split('=',1) for line in raw.splitlines())
  journal=[json.loads(line) for line in (p/f'journal-{kind}-{which}.jsonl').read_text().splitlines()];messages=[x.get('MESSAGE','') for x in journal]
  if kind=='rejected-setup' and which=='ui':assert any('status=1/FAILURE' in x for x in messages)
  else:assert any(x.startswith('Stopped '+unit) for x in messages) and not any('Failed with result' in x or 'Main process exited' in x for x in messages)
  before=show();assert before['MainPID']=='0';assert not Path('/sys/fs/cgroup'+cg).exists(),cg
  stopped=subprocess.run(['systemctl','--user','stop',unit],capture_output=True,text=True)
  assert stopped.returncode==0 or (stopped.returncode==5 and before['LoadState']=='not-found'),(unit,stopped.stderr)
  after=show();assert after['MainPID']=='0' and not Path('/sys/fs/cgroup'+cg).exists()
  unit_audits.append({'kind':kind,'unit':unit,'original_cgroup':cg,'before_exact_final_stop':before,'after_exact_final_stop':after,'stop_returncode':stopped.returncode,'stop_stderr':stopped.stderr,'already_unloaded_is_not_an_execution_status':before['LoadState']=='not-found','exact_cgroup_absent_before_and_after':True,'original_outcome_evidence':'named-unit journal plus driver/CLI final receipts, not unloaded default properties'})
(p/'unit-audits.json').write_text(json.dumps(unit_audits,indent=2)+'\n')
audit={'recovery':'PASS','test_correctness':'PASS' if receipt['job_exit']==0 else 'FAIL','modules':counts,'package_union_exact':True,'package_total':len(all_rows),'failed_packages':failed,'actual_test_exercise_job_launches':1,'earlier_rejected_preflight_wrapper_launches':1,'total_trusted_wrapper_launches_across_separate_sessions':2,'source_files':len(manifest),'source_before_after_current_snapshot_equal':True,'source_manifest_sha256':hashlib.sha256(current.encode()).hexdigest(),'accepted_653_scope_unchanged':True,'installed_pair_unchanged':True,'head_and_graph_unchanged':True,'unit_drains_verified':4,'no_recovery_resubmission':True,'no_local_fallback':True,'no_go_edits':True}
(p/'validation.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit,indent=2))

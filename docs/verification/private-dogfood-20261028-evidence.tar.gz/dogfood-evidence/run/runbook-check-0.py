from pathlib import Path
import json,re,sys
p=Path(sys.argv[1]);r=Path((p/'root').read_text().strip());e=r/'lifecycle/evidence'
result=json.loads((e/'dogfood-result.json').read_text())
cleanup=json.loads((e/'cleanup.json').read_text())
receipt=json.loads((p/'job-result.json').read_text())
assert (p/'driver-exit-code').read_text().strip()=='0'
assert result['recovery']=='PASS' and all(cleanup.values())
assert len((p/'job-launches').read_text().splitlines())==1
seen=[]
for module in ['root','tui']:
    before=(p/f'packages.{module}.before').read_text().splitlines()
    assert before==(p/f'packages.{module}.after').read_text().splitlines()
    assert before==(p/f'preflight.{module}').read_text().splitlines()
    rows=[]
    for line in (p/f'{module}-tests.log').read_text().splitlines():
        m=re.match(r'^(ok|FAIL|\?)\s+(github\.com/unreallabsai/unreal-agent(?:/\S*)?)\s+(.*)$',line)
        if m:
            status,name,tail=m.groups();assert '(cached)' not in tail
            rows.append(name)
    assert len(rows)==len(set(rows)) and sorted(rows)==sorted(before)
    seen.extend(rows)
    print(module,'packages=',len(rows),'actual exit=',receipt[module+'_exit'])
assert len(seen)==57 and len(set(seen))==57
assert receipt['job_exit']==result['job_exit']
print('RECOVERY: PASS')
print('TEST CORRECTNESS:', 'PASS' if receipt['root_exit']==receipt['tui_exit']==0 else 'FAIL')

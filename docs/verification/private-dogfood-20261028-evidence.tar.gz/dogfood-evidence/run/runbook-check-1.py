from pathlib import Path
import json,subprocess,sys
p=Path(sys.argv[1]);x=json.loads((p/'executor-unit.json').read_text())
pairs=[((p/'ui-unit').read_text().strip(),(p/'ui-cgroup').read_text().strip()),(x['unit'],x['cgroup'])]
for unit,cg in pairs:
    fields=subprocess.check_output(['systemctl','--user','show',unit,'-p','LoadState','-p','MainPID','-p','Result','-p','ExecMainStatus'],text=True)
    print(unit,fields,sep='\n')
    state=dict(line.split('=',1) for line in fields.splitlines())
    assert state['MainPID']=='0', 'still running: do not report completion'
    assert not Path('/sys/fs/cgroup'+cg).exists(), 'original cgroup still present'
    stopped=subprocess.run(['systemctl','--user','stop',unit],capture_output=True,text=True)
    assert stopped.returncode==0 or (stopped.returncode==5 and state['LoadState']=='not-found'),stopped.stderr
    assert not Path('/sys/fs/cgroup'+cg).exists()
    print('exact final stop:',stopped.returncode,'(5 allowed only for already-unloaded unit)')
    subprocess.run(['journalctl','--user','-u',unit,'-n','80','--no-pager'],check=True)

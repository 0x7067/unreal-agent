#!/usr/bin/zsh
cd /data/development/projects/0x7067/unreal-agent ||exit 90
python3 '/tmp/unreal-agent-m4-validation.zHSp0I/manifest.py' >'/tmp/unreal-agent-m4-validation.zHSp0I/source.before.sha256'
go list ./... >'/tmp/unreal-agent-m4-validation.zHSp0I/packages.root.before'
go -C cmd/unreal-agent-tui list ./... >'/tmp/unreal-agent-m4-validation.zHSp0I/packages.tui.before'
print -r -- focused >'/tmp/unreal-agent-m4-validation.zHSp0I/phase'
go test -race ./cmd/internal/workerruntime ./cmd/internal/residentcli -run '^TestResumeRefuses|^TestM4' -count=1 -v >'/tmp/unreal-agent-m4-validation.zHSp0I/focused.log' 2>&1
rc=$?
if [[ $rc == 0 ]];then
 for phase in check build test; do
  print -r -- "$phase" >'/tmp/unreal-agent-m4-validation.zHSp0I/phase'
  make "$phase" >'/tmp/unreal-agent-m4-validation.zHSp0I'/make-"$phase".log 2>&1
  rc=$?
  if [[ $rc != 0 ]];then break;fi
 done
fi
python3 '/tmp/unreal-agent-m4-validation.zHSp0I/manifest.py' >'/tmp/unreal-agent-m4-validation.zHSp0I/source.after.sha256'
go list ./... >'/tmp/unreal-agent-m4-validation.zHSp0I/packages.root.after'
go -C cmd/unreal-agent-tui list ./... >'/tmp/unreal-agent-m4-validation.zHSp0I/packages.tui.after'
if ! cmp -s '/tmp/unreal-agent-m4-validation.zHSp0I/source.before.sha256' '/tmp/unreal-agent-m4-validation.zHSp0I/source.after.sha256';then rc=97;fi
print -r -- "$rc" >'/tmp/unreal-agent-m4-validation.zHSp0I/exit-code';print -r -- finished >'/tmp/unreal-agent-m4-validation.zHSp0I/phase';exit $rc

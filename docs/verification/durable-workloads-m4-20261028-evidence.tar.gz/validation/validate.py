from pathlib import Path
import collections, hashlib, json, re, sys
p=Path(sys.argv[1])
assert (p/'exit-code').read_text().strip()=='0','pipeline not successful'
for kind in ('root','tui'):
    before=(p/f'packages.{kind}.before').read_text().splitlines()
    assert before==sorted(before) and len(before)==len(set(before))
    assert before==(p/f'packages.{kind}.after').read_text().splitlines()==(p/f'packages.{kind}.current').read_text().splitlines()
expected=(p/'packages.root.before').read_text().splitlines()+(p/'packages.tui.before').read_text().splitlines()
assert len(expected)==len(set(expected))
log=(p/'make-test.log').read_text()
assert log.count('go test -race ./...\n')==1
assert log.count('go -C cmd/unreal-agent-tui test -race ./...\n')==1
assert not re.search(r'^(FAIL|panic:)|WARNING: DATA RACE',log,re.M)
rows=re.findall(r'^(ok|\?)\s+(\S+)\s+(.*)$',log,re.M)
counts=collections.Counter(row[1] for row in rows)
assert counts==collections.Counter(expected),(counts-collections.Counter(expected),collections.Counter(expected)-counts)
assert all(row[0]=='ok' or '[no test files]' in row[2] for row in rows)
check=(p/'make-check.log').read_text();build=(p/'make-build.log').read_text()
assert 'go vet ./...\n' in check and 'go -C cmd/unreal-agent-tui vet ./...\n' in check
assert 'bin/unreal-agent-runner' in build and 'bin/unreal-agent-tui' in build
source=(p/'source.before.sha256').read_bytes()
assert source==(p/'source.after.sha256').read_bytes()==(p/'source.current.sha256').read_bytes()
report={'status':'PASS','packages':len(expected),'root':len((p/'packages.root.before').read_text().splitlines()),'tui':len((p/'packages.tui.before').read_text().splitlines()),'passing':sum(r[0]=='ok' for r in rows),'no_test_files':sum(r[0]=='?' for r in rows),'source_files':len(source.splitlines()),'source_manifest_sha256':hashlib.sha256(source).hexdigest(),'exact_package_union':True,'before_after_current_equal':True,'race_both_modules':True}
(p/'validation-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

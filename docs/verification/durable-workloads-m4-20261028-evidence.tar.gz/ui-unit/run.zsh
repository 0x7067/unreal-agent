#!/usr/bin/zsh
cd /data/development/projects/0x7067/unreal-agent ||exit 90
sha256sum bin/unreal-agent-runner bin/unreal-agent-tui .claude/skills/verify-unreal-agent-tui/scripts/durable_workloads.py .claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py >'/tmp/unreal-agent-m4-ui.kfSHvp/input.before.sha256'
python3 -I .claude/skills/verify-unreal-agent-tui/scripts/durable_workloads.py '/data/development/projects/0x7067/unreal-agent' '/tmp/u4.1pZBuK' >'/tmp/unreal-agent-m4-ui.kfSHvp/driver.log' 2>&1
rc=$?
sha256sum bin/unreal-agent-runner bin/unreal-agent-tui .claude/skills/verify-unreal-agent-tui/scripts/durable_workloads.py .claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py >'/tmp/unreal-agent-m4-ui.kfSHvp/input.after.sha256'
cmp -s '/tmp/unreal-agent-m4-ui.kfSHvp/input.before.sha256' '/tmp/unreal-agent-m4-ui.kfSHvp/input.after.sha256'||rc=97
print -r -- "$rc" >'/tmp/unreal-agent-m4-ui.kfSHvp/exit-code';exit $rc

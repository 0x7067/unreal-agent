python3 -I '/data/development/projects/0x7067/unreal-agent/.claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py' '/data/development/projects/0x7067/unreal-agent' '/tmp/u21.mmgjcv' > '/tmp/u21.mmgjcv'/driver.log 2>&1
rc=$?
printf "%s\n" "$rc" > '/tmp/u21.mmgjcv'/exit-code
exit "$rc"

package agentrunner

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json/v2"
	"errors"
	"flag"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"slices"
	"strconv"
	"strings"
	"sync"
	"time"
	"uuid"

	"github.com/unreallabsai/unreal-agent/cmd/internal/lifecycleguard"
	"github.com/unreallabsai/unreal-agent/cmd/internal/lifecycleproof"
	"github.com/unreallabsai/unreal-agent/cmd/internal/providers"
	"github.com/unreallabsai/unreal-agent/cmd/internal/recoverygate"
	"github.com/unreallabsai/unreal-agent/cmd/internal/subagent"
	"github.com/unreallabsai/unreal-agent/cmd/internal/xdgpath"
	"github.com/unreallabsai/unreal-agent/harness/contextbuilder"
	"github.com/unreallabsai/unreal-agent/harness/coordinator"
	"github.com/unreallabsai/unreal-agent/harness/executionbudget"
	"github.com/unreallabsai/unreal-agent/harness/inbox"
	"github.com/unreallabsai/unreal-agent/harness/llm"
	"github.com/unreallabsai/unreal-agent/harness/llm/responsesapi"
	"github.com/unreallabsai/unreal-agent/harness/operation"
	"github.com/unreallabsai/unreal-agent/harness/session"
	"github.com/unreallabsai/unreal-agent/harness/sessionstore"
	"github.com/unreallabsai/unreal-agent/harness/sessionstore/localfile"
	"github.com/unreallabsai/unreal-agent/harness/settings"
	"github.com/unreallabsai/unreal-agent/harness/taskgraph"
	"github.com/unreallabsai/unreal-agent/harness/tool"
	"github.com/unreallabsai/unreal-agent/harness/tool/bash"
	toolsubagent "github.com/unreallabsai/unreal-agent/harness/tool/subagent"
	tooltaskgraph "github.com/unreallabsai/unreal-agent/harness/tool/taskgraph"
	"github.com/unreallabsai/unreal-agent/harness/tool/viewimage"
)

const (
	defaultProvider           = "openai"
	llmBaseURLEnvironment     = "UNREAL_HARNESS_LLM_BASE_URL"
	llmModelEnvironment       = "UNREAL_HARNESS_LLM_MODEL"
	llmProviderEnvironment    = "UNREAL_HARNESS_LLM_PROVIDER"
	llmMaxAttemptsEnvironment = "UNREAL_HARNESS_LLM_MAX_ATTEMPTS"
)

const defaultSystemPrompt = `You are an AI agent running inside an isolated sandbox container.

## Guidelines
- Save output files to the workspace root.
- For large datasets, inspect a sample first before processing everything.
`

const subagentSystemPrompt = `## Subagent
You are a subagent started by a parent agent, which reads your final message as your result. Make it a complete, self-contained report. Use SendMessage with to "parent" only for questions or findings the parent needs before you finish.
`

type Request struct {
	Messages               []RequestMessage `json:"messages"`
	Prompt                 *string          `json:"prompt"`
	SystemPrompt           *string          `json:"system_prompt"`
	Model                  string           `json:"model"`
	MaxOutputTokens        *int64           `json:"max_output_tokens"`
	MaxAttempts            *int             `json:"max_attempts"`
	SessionID              *string          `json:"session_id"`
	ThinkingLevel          string           `json:"thinking_level"`
	IncludePartialMessages *bool            `json:"include_partial_messages"`
	ExtraAllowedTools      []string         `json:"extra_allowed_tools"`
	DisallowedTools        []string         `json:"disallowed_tools"`
}

type RequestMessage struct {
	Role      string  `json:"role"`
	Content   string  `json:"content"`
	MessageID *string `json:"message_id"`
}

type environmentChange struct {
	name    string
	value   string
	present bool
}

type environmentScope struct {
	changes []environmentChange
}

type errorEvent struct {
	Type    string `json:"type"`
	Message string `json:"message"`
}

type sessionObserver struct {
	sessionID session.ID
	output    io.Writer
	cancel    context.CancelFunc

	mu  sync.Mutex
	err error
}

func RunMain(
	ctx context.Context,
	args []string,
	getenv func(string) string,
	environ func() []string,
	input io.Reader,
	output io.Writer,
	stderr io.Writer,
	config Config,
) int {
	err := Run(ctx, args, getenv, environ, input, output, stderr, config)
	if err == nil {
		return 0
	}
	if errors.Is(err, flag.ErrHelp) {
		return 0
	}
	if context.Cause(ctx) != nil {
		return 130
	}
	encoded, encodeErr := json.Marshal(errorEvent{Type: "error", Message: err.Error()})
	if encodeErr != nil {
		err = errors.Join(err, fmt.Errorf("encode error event: %w", encodeErr))
	} else if _, writeErr := fmt.Fprintf(output, "%s\n", encoded); writeErr != nil {
		err = errors.Join(err, fmt.Errorf("write error event: %w", writeErr))
	}
	prefix := ""
	if config.Name != "" {
		prefix = config.Name + ": "
	}
	if _, writeErr := fmt.Fprintf(stderr, "%s%v\n", prefix, err); writeErr != nil {
		return 1
	}
	return 1
}

func Run(
	ctx context.Context,
	args []string,
	getenv func(string) string,
	environ func() []string,
	input io.Reader,
	output io.Writer,
	flagOutput io.Writer,
	config Config,
) (runErr error) {
	if strings.TrimSpace(config.Name) == "" {
		return errors.New("runner name must be set")
	}
	if config.ParseRequest == nil {
		return errors.New("request parser must be set")
	}
	ownedInput := input
	flags := flag.NewFlagSet(config.Name, flag.ContinueOnError)
	flags.SetOutput(flagOutput)
	var usageErr error
	flags.Usage = func() {
		usageErr = writeUsage(flags)
	}
	var prompt *string
	flags.Func("p", "send a request with the given `prompt` without reading stdin", func(value string) error {
		prompt = &value
		return nil
	})
	sessionDirectory := flags.String("session-directory", "", "directory containing session files; defaults to $XDG_STATE_HOME/unreal-agent/sessions, or $HOME/.local/state/unreal-agent/sessions")
	loadDotEnvFile := flags.Bool("load-dotenv", false, "trust and load workspace .env (may change credential destinations); ignored for subagents")
	workspaceDirectory := flags.String("workspace", ".", "agent workspace and Bash working directory")
	logDirectory := flags.String("log-directory", "", "optional session JSONL log directory; unset writes only to stdout")
	toolHeartbeatInterval := flags.Duration("tool-heartbeat-interval", 10*time.Minute, "tool-wait heartbeat interval (0 disables)")
	inboxStdin := flags.Bool(strings.TrimPrefix(subagent.InboxStdinFlag, "-"), false, "read JSONL inbox inputs from stdin after the request; without -p or a positional request, the first stdin line is the request")
	isSubagent := flags.Bool(strings.TrimPrefix(subagent.SubagentFlag, "-"), false, "run as a subagent that messages its parent instead of starting subagents")
	var cleanupScope string
	flags.Func(strings.TrimPrefix(subagent.CleanupProofScopeFlag, "-"), "private per-launch cleanup proof scope", func(value string) error {
		if strings.TrimSpace(value) == "" || len(value) > 256 {
			return errors.New("cleanup proof scope must be nonempty and at most 256 bytes")
		}
		cleanupScope = value
		return nil
	})
	if err := flags.Parse(args); err != nil {
		if usageErr != nil {
			if errors.Is(err, flag.ErrHelp) {
				return usageErr
			}
			return errors.Join(err, usageErr)
		}
		return err
	}
	if flags.NArg() > 1 {
		return errors.New("expected at most one positional JSON request")
	}
	if prompt != nil && flags.NArg() != 0 {
		return errors.New("-p cannot be combined with a positional JSON request")
	}
	if *toolHeartbeatInterval < 0 {
		return errors.New("tool heartbeat interval must not be negative")
	}
	if cleanupScope != "" && *inboxStdin {
		prepared, release, err := prepareInput(input)
		if err != nil {
			return fmt.Errorf("prepare cleanup-owned input: %w", err)
		}
		input, ownedInput = prepared, prepared
		defer release()
	}
	inboxInput := bufio.NewReader(input)

	if prompt != nil {
		encoded, err := json.Marshal(struct {
			Prompt string `json:"prompt"`
		}{Prompt: *prompt})
		if err != nil {
			return fmt.Errorf("encode prompt request: %w", err)
		}
		input = bytes.NewReader(encoded)
	} else if flags.NArg() == 1 {
		input = strings.NewReader(flags.Arg(0))
	} else if *inboxStdin {
		// The first stdin line is the request; later lines are inbox inputs.
		raw, err := readLine(ctx, inboxInput)
		if err != nil {
			return fmt.Errorf("read request line: %w", err)
		}
		input = bytes.NewReader(raw)
	} else {
		raw, err := readInput(ctx, input)
		if err != nil {
			return fmt.Errorf("read input: %w", err)
		}
		input = bytes.NewReader(raw)
	}
	parsed, newTools, err := config.ParseRequest(input)
	if err != nil {
		return err
	}
	if newTools == nil {
		return errors.New("request parser returned no tool factory")
	}
	messages, err := validateRequest(parsed)
	if err != nil {
		return err
	}
	workspace, err := filepath.Abs(strings.TrimSpace(*workspaceDirectory))
	if err != nil {
		return fmt.Errorf("resolve workspace: %w", err)
	}
	workspaceInfo, err := os.Stat(workspace)
	if err != nil {
		return fmt.Errorf("inspect workspace: %w", err)
	}
	if !workspaceInfo.IsDir() {
		return fmt.Errorf("workspace %q is not a directory", workspace)
	}
	environment := &environmentScope{}
	if *loadDotEnvFile && !*isSubagent {
		// Only explicit opt-in trusts workspace environment. Subagents inherit
		// their parent's environment even when -load-dotenv is supplied.
		environment, err = loadDotEnv(filepath.Join(workspace, ".env"))
		if err != nil {
			return err
		}
	}
	defer func() {
		if err := environment.Close(); err != nil {
			runErr = errors.Join(runErr, err)
		}
	}()
	maxAttempts, err := resolveMaxAttempts(parsed.MaxAttempts, getenv)
	if err != nil {
		return err
	}

	storeDirectory, err := resolveSessionDirectory(*sessionDirectory, getenv)
	if err != nil {
		return fmt.Errorf("resolve session directory: %w", err)
	}
	// Legacy runner paths may contain platform aliases such as Darwin's /var.
	// Explicitly resolve existing aliases once, then use only the canonical
	// path for both lease and store. AcquireLease independently checks that
	// resolved path's ownership/private ancestry and rejects further symlinks;
	// the original alias is not a trusted security boundary.
	storeDirectory, err = canonicalLeaseDirectory(storeDirectory)
	if err != nil {
		return fmt.Errorf("canonicalize session directory: %w", err)
	}
	// Choose the ID once, before replay or creation, so fresh and resumed
	// sessions use the same exclusive ownership boundary as worker sessions.
	requestedID := uuid.New().String()
	if parsed.SessionID != nil {
		requestedID = strings.TrimSpace(*parsed.SessionID)
	}
	// Standalone/public runners own host authority as well as the session writer
	// lease. Register its release first so session ownership and all cleanup end
	// before authority may pass to a resident host or another runner.
	authority, err := lifecycleguard.AcquireStandaloneOwner(storeDirectory, session.ID(requestedID))
	if err != nil {
		return err
	}
	defer func() {
		if err := authority.Close(); err != nil {
			runErr = errors.Join(runErr, fmt.Errorf("close session authority: %w", err))
		}
	}()
	lease, err := localfile.AcquireLease(storeDirectory, session.ID(requestedID))
	if err != nil {
		return fmt.Errorf("own session %q: %w", requestedID, err)
	}
	// Registered before runtime cleanup: operations and configured tools must
	// finish shutting down before another process may replay this session.
	defer func() {
		if err := lease.Close(); err != nil {
			runErr = errors.Join(runErr, fmt.Errorf("close session lease: %w", err))
		}
	}()
	store, err := localfile.New(storeDirectory)
	if err != nil {
		return fmt.Errorf("open session store: %w", err)
	}
	sessionID, restored, err := openSession(ctx, store, &requestedID)
	if err != nil {
		return err
	}
	lifecycle, err := sessionstore.ReadLifecycle(ctx, store, sessionID)
	if err != nil {
		return fmt.Errorf("read session lifecycle: %w", err)
	}
	if err := lifecycle.ValidateResume(); err != nil {
		return fmt.Errorf("resume session lifecycle: %w", err)
	}
	if err := recoverygate.Validate(restored.Operations); err != nil {
		return fmt.Errorf("refuse resume: operation has unresolved status: %w", err)
	}
	providerName := strings.TrimSpace(getenv(llmProviderEnvironment))
	if providerName == "" {
		providerName = defaultProvider
	}
	selected, err := providers.Find(config.Providers, providerName)
	if err != nil {
		return err
	}
	configuredBaseURL := strings.TrimSpace(getenv(llmBaseURLEnvironment))
	if configuredBaseURL == "" {
		configuredBaseURL = selected.BaseURL
	}

	model := strings.TrimSpace(parsed.Model)
	if model == "" {
		model = strings.TrimSpace(getenv(llmModelEnvironment))
	}
	if model == "" {
		model = selected.DefaultModel
	}
	if model == "" {
		return fmt.Errorf("model must be set in the request or %s", llmModelEnvironment)
	}
	apiKey, err := selected.APIKey(getenv)
	if err != nil {
		return err
	}
	client, err := selected.NewClient(apiKey, configuredBaseURL, maxAttempts, getenv)
	if err != nil {
		return fmt.Errorf("create %s client: %w", selected.Name, err)
	}
	modelOwner := &joinedModelClient{Client: client}
	client = modelOwner
	defer func() {
		if err := client.Close(); err != nil {
			runErr = errors.Join(runErr, fmt.Errorf("close %s client: %w", selected.Name, err))
		}
	}()

	selectedModel := llm.Model{ID: model, MaxOutputTokens: parsed.MaxOutputTokens, ReasoningEffort: reasoningEffort(parsed.ThinkingLevel)}
	configDirectory, err := xdgpath.ConfigDirectory(getenv)
	if err != nil {
		return fmt.Errorf("resolve settings directory: %w", err)
	}
	settingsPath := filepath.Join(configDirectory, "settings.json")
	modelSettings, err := settings.Load(settingsPath)
	if err != nil {
		return fmt.Errorf("load model settings: %w", err)
	}
	selectedModel.CompactionThreshold = modelSettings.Model(selected.Name, selectedModel.ID).CompactionThreshold
	if _, listed := modelSettings.LookupModel(selected.Name, selectedModel.ID); !listed {
		fmt.Fprintf(flagOutput, "warning: provider %q model %q is not listed; using compaction threshold %d tokens; configure %s\n", selected.Name, selectedModel.ID, settings.DefaultCompactionThreshold, settingsPath)
	}

	observedOutput := output
	if directory := strings.TrimSpace(*logDirectory); directory != "" {
		logFile, err := openDatetimeLog(directory, time.Now())
		if err != nil {
			return err
		}
		defer func() {
			if err := logFile.Close(); err != nil {
				runErr = errors.Join(runErr, fmt.Errorf("close session log: %w", err))
			}
		}()
		observedOutput = io.MultiWriter(logFile, output)
	}

	policy, maxOperations, err := executionPolicy(config, getenv)
	if err != nil {
		return err
	}
	account := config.ResourceAccount
	if account == nil {
		account = executionbudget.AccountFromContext(ctx)
	}
	if account == nil {
		account = executionbudget.NewAccount(executionbudget.Limits{MaxOperations: maxOperations})
	}
	runContext, cancel := context.WithCancel(executionbudget.ContextWithAccount(ctx, account))
	defer cancel()
	operationDirectory := filepath.Join(storeDirectory, "operations", string(sessionID))
	if err := os.MkdirAll(operationDirectory, 0o700); err != nil {
		return fmt.Errorf("create operation directory: %w", err)
	}
	shell := strings.TrimSpace(getenv("SHELL"))
	if shell == "" {
		shell = "/bin/sh"
	}
	skills, skillErrors := tool.DiscoverSkills(filepath.Join(workspace, ".harness", "skills"))
	names := []string{tool.BashName, tool.ViewImageName}
	if len(skills) != 0 {
		names = append(names, tool.SkillUseName)
	}
	translators := tool.StaticTranslators{
		Bash: bash.New(bash.Config{
			Shell:         shell,
			Directory:     workspace,
			BaseDirectory: operationDirectory,
		}),
		ViewImage: viewimage.New(viewimage.Config{Directory: workspace}),
	}
	if *isSubagent {
		names = append(names, tool.SendMessageName)
		translators.SendMessage = toolsubagent.NewSendToParent()
	} else {
		names = append(names, tool.TaskGraphName)
		translators.TaskGraph = tooltaskgraph.New()
		if slices.Contains(parsed.ExtraAllowedTools, tool.AgentName) {
			names = append(names, tool.AgentName, tool.SendMessageName, tool.AgentControlName)
			translators.Agent, translators.SendMessage = toolsubagent.NewAgent(), toolsubagent.NewSendMessage()
			translators.AgentControl = toolsubagent.NewAgentControl()
		}
	}
	toolConfig := ToolConfig{SessionID: sessionID, Getenv: getenv, Names: names, Translators: translators}
	configuredTools, err := newTools(runContext, toolConfig)
	if err != nil {
		return err
	}
	var closeToolsOnce sync.Once
	var closeToolsErr error
	closeTools := func() error {
		closeToolsOnce.Do(func() {
			if configuredTools.Close != nil {
				closeToolsErr = configuredTools.Close()
			}
		})
		return closeToolsErr
	}
	defer func() { cancel(); runErr = errors.Join(runErr, closeTools()) }()
	registry := configuredTools.Registry
	if _, enabled := registry.Resolve(tool.SkillUseName); enabled {
		for _, skill := range skills {
			if _, err := registry.RegisterSkill(skill); err != nil {
				return fmt.Errorf("register skill %q: %w", skill.Path, err)
			}
		}
	}
	for _, skillErr := range skillErrors {
		if _, err := fmt.Fprintf(flagOutput, "skill error> %s\n", skillErr); err != nil {
			return fmt.Errorf("write skill error: %w", err)
		}
	}

	inputs, err := inbox.New(runContext, restored.InputIDs)
	if err != nil {
		return fmt.Errorf("open inbox: %w", err)
	}
	remoteJobs := configuredTools.RemoteJobs
	var newAgentHandlers func(context.Context) ([]operation.RemoteJobHandler, error)
	var hub *subagent.Hub
	var supervisorsMu sync.Mutex
	var childSupervisors []*subagent.Supervisor
	var graphRuntime *taskgraph.Runtime
	if _, enabled := registry.Resolve(tool.AgentName); enabled && !*isSubagent && slices.Contains(parsed.ExtraAllowedTools, tool.AgentName) {
		command := config.SubagentCommand
		if command == nil {
			executable, err := os.Executable()
			if err != nil {
				return fmt.Errorf("resolve subagent executable: %w", err)
			}
			command = []string{executable}
		}
		denied := slices.Clone(parsed.DisallowedTools)
		for _, name := range tool.StaticNames() {
			if _, enabled := registry.Resolve(name); !enabled && !slices.Contains(denied, name) {
				denied = append(denied, name)
			}
		}
		denied = append(denied, tool.AgentName, tool.TaskGraphName, tool.AgentControlName)
		hub = subagent.NewHub(runContext)
		defer func() {
			cancel()
			runErr = errors.Join(runErr, hub.Wait(context.Background()))
		}()
		remoteJobs = append(slices.Clip(remoteJobs), hub.Handlers()...)
		childConfig := subagent.Config{
			Hub:     hub,
			Command: command, SessionDirectory: storeDirectory, Workspace: workspace,
			Model: model, ThinkingLevel: parsed.ThinkingLevel, Inbox: inputs, Stderr: flagOutput,
			DisallowedTools: denied, RequireCleanupProof: cleanupScope != "",
		}
		newAgentHandlers = func(ctx context.Context) ([]operation.RemoteJobHandler, error) {
			supervisor, err := subagent.New(ctx, childConfig)
			if err != nil {
				return nil, err
			}
			supervisorsMu.Lock()
			childSupervisors = append(childSupervisors, supervisor)
			supervisorsMu.Unlock()
			return supervisor.Handlers(), nil
		}
		handlers, err := newAgentHandlers(runContext)
		if err != nil {
			return err
		}
		remoteJobs = append(slices.Clip(remoteJobs), handlers...)
	}
	if _, enabled := registry.Resolve(tool.TaskGraphName); enabled && !*isSubagent && !slices.Contains(parsed.DisallowedTools, tool.TaskGraphName) {
		_, allowBash := registry.Resolve(tool.BashName)
		runtime, err := taskgraph.New(runContext, taskgraph.Config{Workspace: workspace, Shell: shell, BaseDirectory: operationDirectory, Inbox: inputs, AllowBash: allowBash, NewAgentHandlers: newAgentHandlers, ResourceAccount: account, Budget: policy})
		if err != nil {
			return err
		}
		graphRuntime = runtime
		remoteJobs = append(slices.Clip(remoteJobs), runtime.Handlers()...)
	}
	operations := operation.NewLocalOperationManagerWithOptions(runContext, operation.LocalOperationManagerOptions{OutputDirectory: operationDirectory, ResourceAccount: account, Budget: policy}, remoteJobs...)
	defer func() {
		cancel()
		for range operations.Updates() {
		}
	}()
	settingsPayload, err := json.Marshal(inbox.ControlMessage{
		Mode: inbox.UpdateSettings,
		Parameters: inbox.Settings{
			Model:               model,
			CompactionThreshold: new(selectedModel.CompactionThreshold),
			MaxOutputTokens:     parsed.MaxOutputTokens,
			ReasoningEffort:     reasoningEffort(parsed.ThinkingLevel),
		},
	})
	if err != nil {
		return fmt.Errorf("encode settings: %w", err)
	}
	if err := inputs.Submit(runContext, inbox.Input{
		ID: inbox.ID(uuid.New().String()), Kind: inbox.InputControl, Payload: settingsPayload,
	}); err != nil {
		return fmt.Errorf("submit settings: %w", err)
	}
	for index, message := range messages {
		payload, err := json.Marshal(message.Content)
		if err != nil {
			return fmt.Errorf("encode message %d: %w", index, err)
		}
		var messageID inbox.ID
		if message.MessageID != nil {
			messageID = inbox.ID(strings.TrimSpace(*message.MessageID))
		} else {
			messageID = inbox.ID(uuid.New().String())
		}
		if err := inputs.Submit(runContext, inbox.Input{
			ID: messageID, Kind: inbox.InputExternal, Payload: payload,
		}); err != nil {
			return fmt.Errorf("submit message %d: %w", index, err)
		}
	}

	stopPayload, err := json.Marshal(inbox.ControlMessage{Mode: inbox.StopWhenIdle})
	if err != nil {
		return fmt.Errorf("encode stop request: %w", err)
	}
	if err := inputs.Submit(runContext, inbox.Input{
		ID: inbox.ID(uuid.New().String()), Kind: inbox.InputControl, Payload: stopPayload,
	}); err != nil {
		return fmt.Errorf("submit stop request: %w", err)
	}
	var inputDone chan struct{}
	if *inboxStdin {
		inputDone = make(chan struct{})
		go func() { defer close(inputDone); submitInboxLines(runContext, inboxInput, inputs, flagOutput) }()
	}

	builder := contextbuilder.NewBuilder(registry.Skills()...)
	builder.SetModel(selectedModel)
	systemPrompt := defaultSystemPrompt
	if parsed.SystemPrompt != nil {
		systemPrompt = *parsed.SystemPrompt
	}
	if *isSubagent {
		systemPrompt = strings.TrimSpace(systemPrompt) + "\n\n" + subagentSystemPrompt
	}
	builder.SetSystemPrompt(systemPrompt)
	for _, definition := range registry.StaticDefinitions() {
		builder.AddTool(definition.Tool)
	}

	observer := &sessionObserver{
		sessionID: sessionID,
		output:    observedOutput,
		cancel:    cancel,
	}
	observerID := store.AddObserver(observer.Observe)
	defer store.RemoveObserver(observerID)
	// This defer precedes observer removal and lease release, but follows the
	// coordinator return. Never infer effect cleanup from terminal updates.
	defer func() {
		if cleanupScope == "" {
			return
		}
		cancel()
		for range operations.Updates() {
		}
		// Retain the direct manager error: wrapping or joining it before
		// reconciliation could hide independent failure evidence.
		managerErr := operations.AwaitStopped(context.Background())
		ownersErr := closeTools()
		if graphRuntime != nil {
			ownersErr = errors.Join(ownersErr, graphRuntime.Wait(context.Background()))
		}
		supervisorsMu.Lock()
		supervisors := slices.Clone(childSupervisors)
		supervisorsMu.Unlock()
		for _, supervisor := range supervisors {
			ownersErr = errors.Join(ownersErr, supervisor.Wait(context.Background()))
		}
		if hub != nil {
			ownersErr = errors.Join(ownersErr, hub.Wait(context.Background()))
		}
		ownersErr = errors.Join(ownersErr, modelOwner.Close())
		if inputDone != nil {
			if file, ok := ownedInput.(*os.File); ok && file.SetReadDeadline(time.Now()) == nil {
				// Interrupt only the private pollable read, then join before
				// prepareInput restores shared descriptor flags and closes it.
				<-inputDone
				_ = file.SetReadDeadline(time.Time{})
			} else if closer, ok := ownedInput.(io.Closer); ok {
				_ = closer.Close()
				<-inputDone
			} else {
				select {
				case <-inputDone:
				default:
					ownersErr = errors.Join(ownersErr, errors.New("inbox reader cleanup unproven"))
				}
			}
		}
		// Cancellation closes the inbox actor; join it as well as the reader.
		for range inputs.Output() {
		}
		// Read the original canonical specs, including structural controls still
		// present only in Resume. Terminal status is never cleanup evidence.
		history, historyErr := sessionstore.ReadLifecycle(context.Background(), store, sessionID)
		resumed, resumeErr := store.Resume(context.Background(), sessionID)
		ownersErr = errors.Join(ownersErr, historyErr, resumeErr)
		if history.RemoteOperations == nil {
			history.RemoteOperations = map[operation.ID]operation.Operation{}
		}
		for _, op := range resumed.Operations {
			if op.Type == operation.TypeRemoteJob {
				history.RemoteOperations[op.ID] = op
			}
		}
		// These capabilities are established only by actual joins above. The
		// graph join precedes the snapshot so dynamic supervisors cannot escape.
		joined := map[operation.RemoteJobPlanType]operation.RemoteJobPlanVersion{}
		if graphRuntime != nil {
			joined[taskgraph.RunPlanType] = taskgraph.PlanVersion
			joined[taskgraph.ControlPlanType] = taskgraph.PlanVersion
		}
		if hub != nil {
			joined[toolsubagent.RunPlanType] = toolsubagent.PlanVersion
			joined[toolsubagent.MessagePlanType] = toolsubagent.PlanVersion
			joined[toolsubagent.ControlPlanType] = toolsubagent.PlanVersion
		}
		cleanupErr := lifecycleproof.Reconcile(managerErr, ownersErr, history.RemoteOperations, joined)
		if cleanupErr == nil && observer.Err() == nil {
			payload, err := json.Marshal(inbox.ControlMessage{Mode: inbox.ExecutionDrained, Parameters: inbox.ExecutionDrainReceipt{Version: 1, Scope: cleanupScope}})
			if err == nil {
				err = store.AppendInput(context.Background(), sessionID, inbox.Input{ID: inbox.ID(uuid.New().String()), Kind: inbox.InputControl, Payload: payload})
			}
			cleanupErr = errors.Join(err, observer.Err())
		}
		runErr = errors.Join(runErr, cleanupErr)
	}()
	current := coordinator.New(coordinator.Dependencies{
		ToolHeartbeatInterval: *toolHeartbeatInterval,
		ActivitySummary:       func() string { return runnerActivitySummary(hub, operations) },
		SessionID:             sessionID,
		Inbox:                 inputs,
		Restored:              restored,
		Sessions:              store,
		ContextBuilder:        builder,
		LLM:                   client,
		Tools:                 registry,
		Operations:            operations,
	})
	coordinatorErr := current.Run(runContext)
	if observerErr := observer.Err(); observerErr != nil {
		return observerErr
	}
	if coordinatorErr != nil {
		return fmt.Errorf("run coordinator: %w", coordinatorErr)
	}
	return nil
}

// submitInboxLines submits each JSONL inbox input read from input. Invalid
// lines are reported and skipped.
func submitInboxLines(ctx context.Context, input io.Reader, inputs inbox.Writer, errors io.Writer) {
	lines := bufio.NewReader(input)
	for {
		line, readErr := lines.ReadBytes('\n')
		if line = bytes.TrimSpace(line); len(line) != 0 {
			var received inbox.Input
			err := json.Unmarshal(line, &received)
			if err == nil {
				err = inputs.Submit(ctx, received)
			}
			if ctx.Err() != nil {
				return
			}
			if err != nil {
				_, _ = fmt.Fprintf(errors, "inbox input> %s\n", err)
			}
		}
		if readErr != nil {
			return
		}
	}
}

func resolveMaxAttempts(requested *int, getenv func(string) string) (int, error) {
	maxAttempts := responsesapi.DefaultMaxAttempts
	if requested != nil {
		maxAttempts = *requested
	} else if value := strings.TrimSpace(getenv(llmMaxAttemptsEnvironment)); value != "" {
		parsed, err := strconv.Atoi(value)
		if err != nil {
			return 0, fmt.Errorf("parse %s: %w", llmMaxAttemptsEnvironment, err)
		}
		maxAttempts = parsed
	}
	if maxAttempts <= 0 {
		return 0, errors.New("max attempts must be positive")
	}
	return maxAttempts, nil
}

func readLine(ctx context.Context, input *bufio.Reader) ([]byte, error) {
	var line []byte
	var err error
	done := make(chan struct{})
	go func() {
		line, err = input.ReadBytes('\n')
		if err == io.EOF && len(bytes.TrimSpace(line)) != 0 {
			err = nil
		}
		close(done)
	}()
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-done:
		return line, err
	}
}

func readInput(ctx context.Context, input io.Reader) ([]byte, error) {
	var raw []byte
	var err error
	done := make(chan struct{})
	// A blocked stdin read can outlive cancellation until Main exits the process.
	go func() {
		raw, err = io.ReadAll(input)
		close(done)
	}()
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-done:
		return raw, err
	}
}

func DecodeRequest(input io.Reader, destination any) error {
	raw, err := io.ReadAll(input)
	if err != nil {
		return fmt.Errorf("read input: %w", err)
	}
	raw = bytes.TrimSpace(raw)
	if len(raw) == 0 {
		return errors.New("empty input")
	}
	if err := json.Unmarshal(raw, destination, json.RejectUnknownMembers(true)); err != nil {
		return fmt.Errorf("invalid JSON: %w", err)
	}
	return nil
}

func resolveSessionDirectory(configured string, getenv func(string) string) (string, error) {
	if configured = strings.TrimSpace(configured); configured != "" {
		return filepath.Abs(configured)
	}
	directory, err := xdgpath.SessionDirectory(getenv)
	if err != nil {
		return "", fmt.Errorf("%w; specify -session-directory to override", err)
	}
	return directory, nil
}

// canonicalLeaseDirectory resolves the existing prefix without creating any
// directories through symlinks. Missing suffixes are created later by the secure
// descriptor-relative lease traversal, not by MkdirAll on the caller's alias.
func canonicalLeaseDirectory(directory string) (string, error) {
	absolute, err := filepath.Abs(directory)
	if err != nil {
		return "", err
	}
	prefix := absolute
	var missing []string
	for {
		resolved, err := filepath.EvalSymlinks(prefix)
		if err == nil {
			for i := len(missing) - 1; i >= 0; i-- {
				resolved = filepath.Join(resolved, missing[i])
			}
			return resolved, nil
		}
		if !errors.Is(err, os.ErrNotExist) || filepath.Dir(prefix) == prefix {
			return "", err
		}
		missing = append(missing, filepath.Base(prefix))
		prefix = filepath.Dir(prefix)
	}
}

func openDatetimeLog(directory string, now time.Time) (*os.File, error) {
	if err := os.MkdirAll(directory, 0o700); err != nil {
		return nil, fmt.Errorf("create log directory: %w", err)
	}
	path := filepath.Join(directory, now.UTC().Format("20060102-150405")+".jsonl")
	file, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o600)
	if err != nil {
		return nil, fmt.Errorf("open session log: %w", err)
	}
	return file, nil
}

// LoadDotEnv sets the variables in a .env file that the environment does not
// already set, except SANDBOX_EGRESS_PROXY (also copied to HTTPS_PROXY).
// This explicit API trusts the file, including endpoint/proxy settings; CLI
// callers must opt in with -load-dotenv. Close restores the previous environment.
func LoadDotEnv(path string) (io.Closer, error) {
	scope, err := loadDotEnv(path)
	if err != nil {
		return nil, err
	}
	return scope, nil
}

func loadDotEnv(path string) (*environmentScope, error) {
	encoded, err := os.ReadFile(path)
	if err != nil {
		if errors.Is(err, fs.ErrNotExist) {
			return &environmentScope{}, nil
		}
		return nil, fmt.Errorf("read environment file: %w", err)
	}
	values := make(map[string]string)
	for line := range strings.Lines(string(encoded)) {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		name, value, exists := strings.Cut(line, "=")
		if !exists {
			continue
		}
		name = strings.TrimSpace(name)
		if name == "" {
			continue
		}
		values[name] = strings.TrimSpace(value)
	}
	scope := &environmentScope{}
	for name, value := range values {
		_, present := os.LookupEnv(name)
		if present && name != "SANDBOX_EGRESS_PROXY" {
			continue
		}
		if err := scope.set(name, value); err != nil {
			return nil, errors.Join(err, scope.Close())
		}
	}
	if proxy := os.Getenv("SANDBOX_EGRESS_PROXY"); proxy != "" {
		if err := scope.set("HTTPS_PROXY", proxy); err != nil {
			return nil, errors.Join(err, scope.Close())
		}
	}
	return scope, nil
}

func (scope *environmentScope) set(name, value string) error {
	previous, present := os.LookupEnv(name)
	if err := os.Setenv(name, value); err != nil {
		return fmt.Errorf("set environment variable %q: %w", name, err)
	}
	scope.changes = append(scope.changes, environmentChange{
		name: name, value: previous, present: present,
	})
	return nil
}

func (scope *environmentScope) Close() error {
	var closeErr error
	for _, change := range slices.Backward(scope.changes) {
		var err error
		if change.present {
			err = os.Setenv(change.name, change.value)
		} else {
			err = os.Unsetenv(change.name)
		}
		if err != nil {
			closeErr = errors.Join(
				closeErr,
				fmt.Errorf("restore environment variable %q: %w", change.name, err),
			)
		}
	}
	scope.changes = nil
	return closeErr
}

func validateRequest(parsed Request) ([]RequestMessage, error) {
	if parsed.MaxOutputTokens != nil && *parsed.MaxOutputTokens <= 0 {
		return nil, errors.New("max_output_tokens must be positive")
	}
	if parsed.SessionID != nil && strings.TrimSpace(*parsed.SessionID) == "" {
		return nil, errors.New("session_id must not be empty")
	}
	if parsed.ThinkingLevel != "" {
		switch parsed.ThinkingLevel {
		case "low", "medium", "high", "xhigh", "max":
		default:
			return nil, errors.New("thinking_level must be one of: low, medium, high, xhigh, max")
		}
	}
	for _, name := range append(parsed.ExtraAllowedTools, parsed.DisallowedTools...) {
		if strings.TrimSpace(name) == "" {
			return nil, errors.New("tool names must not be empty")
		}
	}

	if parsed.Messages == nil {
		if parsed.Prompt == nil {
			return nil, errors.New("messages must be set")
		}
		return []RequestMessage{{Content: *parsed.Prompt}}, nil
	}
	if len(parsed.Messages) == 0 {
		return nil, errors.New("messages must not be empty")
	}
	for index, message := range parsed.Messages {
		if message.Role != "" && message.Role != "user" {
			return nil, fmt.Errorf("messages[%d].role must be user", index)
		}
		if message.MessageID != nil && strings.TrimSpace(*message.MessageID) == "" {
			return nil, fmt.Errorf("messages[%d].message_id must not be empty", index)
		}
		if message.MessageID != nil {
			if _, err := uuid.Parse(strings.TrimSpace(*message.MessageID)); err != nil {
				return nil, fmt.Errorf("messages[%d].message_id must be a UUID", index)
			}
		}
	}
	return parsed.Messages, nil
}

func reasoningEffort(level string) llm.ReasoningEffort {
	switch level {
	case "low":
		return llm.ReasoningEffortLow
	case "medium":
		return llm.ReasoningEffortMedium
	case "xhigh":
		return llm.ReasoningEffortXHigh
	case "max":
		return llm.ReasoningEffortMax
	default:
		return llm.ReasoningEffortHigh
	}
}

func openSession(
	ctx context.Context,
	store *localfile.Store,
	requested *string,
) (session.ID, sessionstore.ResumeState, error) {
	id := session.ID(uuid.New().String())
	if requested != nil {
		id = session.ID(strings.TrimSpace(*requested))
	}
	restored, err := store.Resume(ctx, id)
	if err == nil {
		return id, restored, nil
	}
	if !errors.Is(err, fs.ErrNotExist) {
		return "", sessionstore.ResumeState{}, fmt.Errorf("open session %q: %w", id, err)
	}
	snapshot, err := store.Create(ctx, id)
	if err != nil {
		return "", sessionstore.ResumeState{}, fmt.Errorf("create session %q: %w", id, err)
	}
	return id, sessionstore.ResumeState{Snapshot: snapshot}, nil
}

func (observer *sessionObserver) Observe(sessionID session.ID, item sessionstore.Item) {
	if sessionID != observer.sessionID {
		return
	}
	observer.mu.Lock()
	defer observer.mu.Unlock()
	if observer.err != nil {
		return
	}
	if err := writeSessionItem(observer.output, item); err != nil {
		observer.fail(err)
		return
	}
}

func writeSessionItem(output io.Writer, item sessionstore.Item) error {
	encoded, err := json.Marshal(item)
	if err != nil {
		return fmt.Errorf("encode session item %d: %w", item.Sequence, err)
	}
	if _, err := fmt.Fprintf(output, "%s\n", encoded); err != nil {
		return fmt.Errorf("write session item %d: %w", item.Sequence, err)
	}
	return nil
}

func (observer *sessionObserver) fail(err error) {
	observer.err = err
	observer.cancel()
}

func (observer *sessionObserver) Err() error {
	observer.mu.Lock()
	defer observer.mu.Unlock()
	return observer.err
}

// joinedModelClient seals new callbacks before joining all admitted Respond calls.
// Provider Close is not itself a universal Respond join contract.
type joinedModelClient struct {
	providers.Client
	mu       sync.Mutex
	sealed   bool
	calls    sync.WaitGroup
	once     sync.Once
	closeErr error
}

func (c *joinedModelClient) Respond(ctx context.Context, request llm.Request, options llm.RequestOptions) (llm.Response, error) {
	c.mu.Lock()
	if c.sealed {
		c.mu.Unlock()
		return llm.Response{}, context.Canceled
	}
	c.calls.Add(1)
	c.mu.Unlock()
	defer c.calls.Done()
	return c.Client.Respond(ctx, request, options)
}
func (c *joinedModelClient) Close() error {
	c.once.Do(func() {
		c.mu.Lock()
		c.sealed = true
		c.mu.Unlock()
		c.closeErr = c.Client.Close()
		c.calls.Wait()
	})
	return c.closeErr
}

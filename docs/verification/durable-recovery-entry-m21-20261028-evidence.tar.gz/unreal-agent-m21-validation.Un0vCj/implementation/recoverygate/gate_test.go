package recoverygate

import (
	"encoding/json/jsontext"
	"errors"
	"reflect"
	"slices"
	"strings"
	"testing"

	"github.com/unreallabsai/unreal-agent/harness/operation"
)

func ready() operation.Operation {
	return operation.Operation{ID: "value-1", Type: operation.TypeValue, Version: operation.VersionValue, Status: operation.StatusReady, State: jsontext.Value(`{"Value":{"ok":true}}`)}
}

func TestValidReadyValue(t *testing.T) {
	for _, state := range []string{`{"Value":{"ok":true}}`, `{"Value":null}`, `{"Value":[1,"a"]}`} {
		op := ready()
		op.State = jsontext.Value(state)
		if err := Validate([]operation.Operation{op}); err != nil {
			t.Fatal(err)
		}
	}
	if err := Validate(nil); err != nil {
		t.Fatal(err)
	}
}

func TestRefusedStates(t *testing.T) {
	for _, state := range []string{"", "{", `{}`, `{"Value":}`, `{"Value":1,"Value":2}`, `null`} {
		t.Run(state, func(t *testing.T) {
			op := ready()
			op.State = jsontext.Value(state)
			_, original := operation.DecodeValue(op)
			if original == nil {
				t.Fatalf("fixture unexpectedly decodes: %s", state)
			}
			err := Validate([]operation.Operation{op})
			if err == nil || errors.Unwrap(err) == nil || errors.Unwrap(err).Error() != original.Error() {
				t.Fatalf("original cause lost: %v", err)
			}
			for _, s := range []string{`id="value-1"`, `type="value"`, `version=1`, `status="ready"`, "invalid value state", original.Error()} {
				if !strings.Contains(err.Error(), s) {
					t.Errorf("%q missing %q", err, s)
				}
			}
		})
	}
}

func TestRecoveryTypeVersionStatusMatrix(t *testing.T) {
	image, err := operation.NewViewImageSpec("/owned/image.png", operation.ViewImageConfig{MaxSize: 1024, MaxWidth: 16, MaxHeight: 16})
	if err != nil {
		t.Fatal(err)
	}
	types := []operation.Type{operation.TypeValue, operation.TypeViewImage, operation.TypeSkillUse, operation.TypeShell, operation.TypeRemoteJob, "", "unknown", "subagent.run", "taskgraph.run"}
	statuses := []operation.Status{operation.StatusReady, operation.StatusAwaiting, operation.StatusCanceling, operation.StatusUnsupported, "unknown", "running"}
	for _, typ := range types {
		for _, version := range []operation.Version{0, 1, 2, 3, 4, 5, ^operation.Version(0)} {
			for _, status := range statuses {
				op := ready()
				op.Type = typ
				if typ == operation.TypeViewImage {
					op.State = image.State.Clone()
				}
				op.Version = version
				op.Status = status
				err := Validate([]operation.Operation{op})
				allowed := (typ == operation.TypeValue && version == operation.VersionValue || typ == operation.TypeViewImage && version == operation.VersionViewImage) && status == operation.StatusReady
				if allowed != (err == nil) {
					t.Fatalf("%+v: %v", op, err)
				}
				if !allowed && !errors.Is(err, operation.ErrUnsupported) {
					t.Fatalf("not conservative unsupported error: %v", err)
				}
			}
		}
	}
	op := ready()
	op.ID = ""
	if err := Validate([]operation.Operation{op}); err == nil || !strings.Contains(err.Error(), "missing operation identity") {
		t.Fatalf("empty identity: %v", err)
	}
}

func TestTerminalHistoryIsInert(t *testing.T) {
	for _, status := range []operation.Status{operation.StatusCompleted, operation.StatusFailed, operation.StatusCanceled} {
		for _, typ := range []operation.Type{"", "unknown", operation.TypeValue, operation.TypeShell, operation.TypeRemoteJob} {
			op := operation.Operation{Type: typ, Version: ^operation.Version(0), Status: status, State: jsontext.Value(`not JSON`)}
			if err := Validate([]operation.Operation{op}); err != nil {
				t.Fatal(err)
			}
		}
	}
}

func TestDeterministicBoundedDiagnosticsAndNoMutation(t *testing.T) {
	a := ready()
	a.ID = "a"
	a.State = jsontext.Value(`{`)
	b := a
	b.State = jsontext.Value(`{}`)
	b.Idempotency = jsontext.Value(`{"key":1}`)
	c := ready()
	c.ID = "z"
	c.Type = operation.TypeShell
	ops := []operation.Operation{c, b, a}
	before := make([]operation.Operation, len(ops))
	for i, op := range ops {
		before[i] = op
		before[i].State = slices.Clone(op.State)
		before[i].Idempotency = slices.Clone(op.Idempotency)
	}
	first := Validate(ops)
	if first == nil || !strings.Contains(first.Error(), `id="a"`) {
		t.Fatalf("wrong first refusal: %v", first)
	}
	if !reflect.DeepEqual(ops, before) {
		t.Fatal("input mutated")
	}
	for _, order := range [][]operation.Operation{{a, b, c}, {b, c, a}, {c, a, b}, {b, a, c}, {a, c, b}} {
		if got := Validate(order); got == nil || got.Error() != first.Error() {
			t.Fatalf("unstable refusal: %v vs %v", got, first)
		}
	}
	huge := ready()
	huge.ID = operation.ID(strings.Repeat("\x00\n", 10000))
	huge.Type = operation.Type(strings.Repeat("type", 10000))
	huge.Status = operation.Status(strings.Repeat("status", 10000))
	err := Validate([]operation.Operation{huge})
	if err == nil || len(err.Error()) > 2048 || strings.Contains(err.Error(), "\n") {
		t.Fatalf("unbounded/unsafe diagnostic: %v", err)
	}
	for _, label := range []string{"id=", "type=", "version=", "status=", "..."} {
		if !strings.Contains(err.Error(), label) {
			t.Errorf("missing %s", label)
		}
	}
	huge = ready()
	huge.ID = operation.ID(strings.Repeat("x", 10000))
	huge.State = jsontext.Value(`{`)
	err = Validate([]operation.Operation{huge})
	if err == nil || len(err.Error()) > 2048 || errors.Unwrap(err) == nil || !strings.Contains(err.Error(), "invalid value state") {
		t.Fatalf("decode bounds/cause: %v", err)
	}
	valid := []operation.Operation{ready()}
	saved := slices.Clone(valid[0].State)
	if err := Validate(valid); err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(saved, valid[0].State) {
		t.Fatal("valid state mutated")
	}
}

func TestInitialImageIsNarrowlyApproved(t *testing.T) {
	spec, err := operation.NewViewImageSpec("/owned/current.png", operation.ViewImageConfig{MaxSize: 1024, MaxHeight: 16, MaxWidth: 16})
	if err != nil {
		t.Fatal(err)
	}
	op := operation.Operation{ID: "image-intent", Type: spec.Type, Version: spec.Version, Status: operation.StatusReady, State: spec.State.Clone()}
	if err := Validate([]operation.Operation{op}); err != nil {
		t.Fatal(err)
	}
	for _, which := range []string{"future", "malformed", "empty-path", "result", "awaiting", "canceling"} {
		t.Run(which, func(t *testing.T) {
			bad := op
			switch which {
			case "future":
				bad.Version++
			case "malformed":
				bad.State = jsontext.Value(`{`)
			case "empty-path":
				bad.State = jsontext.Value(`{"Path":"","Config":{"MaxSize":10,"MaxHeight":1,"MaxWidth":1}}`)
			case "result":
				bad.State = jsontext.Value(`{"Path":"/owned/current.png","Config":{"MaxSize":10,"MaxHeight":1,"MaxWidth":1},"Result":{}}`)
			case "awaiting":
				bad.Status = operation.StatusAwaiting
			case "canceling":
				bad.Status = operation.StatusCanceling
			}
			if err := Validate([]operation.Operation{bad}); err == nil {
				t.Fatalf("unclassified image accepted: %+v", bad)
			}
		})
	}
}

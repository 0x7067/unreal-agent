go test -race ./cmd/internal/workerhost -run "^TestM21" -count=1 -timeout=60s -v > '/tmp/unreal-agent-m21-restart.CApVHc'/test.log 2>&1
rc=$?
printf "%s\n" "$rc" > '/tmp/unreal-agent-m21-restart.CApVHc'/exit-code
exit "$rc"

python3 -I '/data/development/projects/0x7067/unreal-agent/.claude/skills/verify-unreal-agent-tui/scripts/durable_reconnect.py' '/data/development/projects/0x7067/unreal-agent' '/tmp/u21.pxE5vH' > '/tmp/u21.pxE5vH'/driver.log 2>&1
rc=$?
printf "%s\n" "$rc" > '/tmp/u21.pxE5vH'/exit-code
exit "$rc"

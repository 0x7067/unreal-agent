#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
python3 -I .claude/skills/verify-unreal-agent-tui/scripts/durable_upgrade.py '/data/development/projects/0x7067/unreal-agent' '/tmp/u31.ROiQgS' '/tmp/unreal-agent-m31-build.fhkQ1z/frontend-a' '/tmp/unreal-agent-m31-build.fhkQ1z/frontend-b' '/tmp/unreal-agent-m31-build.fhkQ1z/frontend-incompatible' >'/tmp/unreal-agent-m31-ui.YEZc18/test.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m31-ui.YEZc18/exit-code';exit $rc

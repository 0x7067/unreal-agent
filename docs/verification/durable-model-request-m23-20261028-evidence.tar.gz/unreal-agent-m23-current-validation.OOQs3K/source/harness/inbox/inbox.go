// Package inbox owns input deduplication for one session.
package inbox

import (
	"context"
	"encoding/json/jsontext"
	"encoding/json/v2"
	"fmt"
	"strings"

	"github.com/unreallabsai/unreal-agent/harness/llm"
)

type ID string

type InputKind string

const (
	InputExternal InputKind = "external"
	InputControl  InputKind = "control"
	InputCrash    InputKind = "crash"
)

type Input struct {
	ID      ID
	Kind    InputKind
	Payload jsontext.Value `json:",omitzero"`
}

func (input Input) Validate() error {
	if input.ID == "" {
		return fmt.Errorf("input ID is empty")
	}
	switch input.Kind {
	case InputExternal, InputCrash:
	case InputControl:
		if _, err := input.DecodeControlMessage(); err != nil {
			return err
		}
	default:
		return fmt.Errorf("input %q has unsupported kind %q", input.ID, input.Kind)
	}
	if input.Payload != nil && !input.Payload.IsValid() {
		return fmt.Errorf("input %q payload is not valid JSON", input.ID)
	}
	return nil
}

type ControlMode string

const (
	InvokeTool             ControlMode = "invoke_tool"
	ToolInvocationFinished ControlMode = "tool_invocation_finished"
	StopHard               ControlMode = "hard"
	StopWhenIdle           ControlMode = "when_idle"
	Heartbeat              ControlMode = "heartbeat"
	UpdateSettings         ControlMode = "settings"
	Compact                ControlMode = "compact"
	CompactionDisabled     ControlMode = "compaction_disabled"
	SetCompactionPolicy    ControlMode = "compaction_policy"
)

// CompactionPolicy is recorded before the first summary request so the retry
// bound survives replay, including a restart with different dependencies.
type CompactionPolicy struct {
	FailureLimit int
}

type Settings struct {
	Model               string              `json:",omitzero"`
	CompactionThreshold *int64              `json:",omitzero"`
	MaxOutputTokens     *int64              `json:",omitzero"`
	ReasoningEffort     llm.ReasoningEffort `json:",omitzero"`
}

// ToolInvocation requests a registered structural control without a model turn.
// Only AgentControl is admitted; ordinary execution still uses model tool calls.
type ToolInvocation struct {
	Call llm.ToolCall
}

// ToolInvocationResult is emitted only after an operation checkpoint is durable.
// A completed stop operation may acknowledge a request, not descendant drain.
type ToolInvocationResult struct {
	InputID ID
	CallID  string
	Status  string
	Text    string
	Error   string
}

type ControlMessage struct {
	Mode       ControlMode
	Reason     string
	Parameters any `json:",omitzero"`
}

func (input Input) DecodeControlMessage() (ControlMessage, error) {
	if input.Kind != InputControl {
		return ControlMessage{}, fmt.Errorf("control message input has kind %q", input.Kind)
	}
	var envelope struct {
		Mode       ControlMode
		Reason     string
		Parameters jsontext.Value
	}
	if err := json.Unmarshal(input.Payload, &envelope, json.RejectUnknownMembers(true)); err != nil {
		return ControlMessage{}, fmt.Errorf("decode control message: %w", err)
	}
	request := ControlMessage{Mode: envelope.Mode, Reason: envelope.Reason}
	if request.Mode != ModelRequest && request.Mode != UpdateSettings && request.Mode != SetCompactionPolicy && request.Mode != InvokeTool && request.Mode != ToolInvocationFinished && request.Mode != AbortForeground && request.Mode != ForegroundAbortFinished && request.Mode != ShutdownSession && request.Mode != SessionShutdownFinished && request.Mode != ExecutionDrained && len(envelope.Parameters) != 0 {
		return ControlMessage{}, fmt.Errorf("control mode %q does not accept parameters", request.Mode)
	}
	switch request.Mode {
	case ModelRequest:
		if len(request.Reason) > 2048 {
			return ControlMessage{}, fmt.Errorf("model request reason exceeds 2048 bytes")
		}
		value, err := decodeModelRequest(envelope.Parameters)
		if err != nil {
			return ControlMessage{}, err
		}
		request.Parameters = value
	case ShutdownSession, SessionShutdownFinished, ExecutionDrained:
		value, err := decodeOwnedLifecycle(request.Mode, envelope.Parameters)
		if err != nil {
			return ControlMessage{}, err
		}
		request.Parameters = value
	case AbortForeground:
		value, err := decodeForegroundAbort(envelope.Parameters)
		if err != nil {
			return ControlMessage{}, err
		}
		request.Parameters = value
	case ForegroundAbortFinished:
		value, err := decodeForegroundAbortResult(envelope.Parameters)
		if err != nil {
			return ControlMessage{}, err
		}
		request.Parameters = value
	case InvokeTool:
		var invocation ToolInvocation
		if err := json.Unmarshal(envelope.Parameters, &invocation, json.RejectUnknownMembers(true)); err != nil {
			return ControlMessage{}, fmt.Errorf("decode tool invocation: %w", err)
		}
		if invocation.Call.Name != "AgentControl" || strings.TrimSpace(invocation.Call.CallID) == "" || len(invocation.Call.CallID) > 128 || len(invocation.Call.Arguments) > 64<<10 {
			return ControlMessage{}, fmt.Errorf("invalid structural AgentControl invocation")
		}
		if !jsontext.Value(invocation.Call.Arguments).IsValid() {
			return ControlMessage{}, fmt.Errorf("invalid structural control arguments JSON")
		}
		request.Parameters = invocation
	case ToolInvocationFinished:
		var result ToolInvocationResult
		if err := json.Unmarshal(envelope.Parameters, &result, json.RejectUnknownMembers(true)); err != nil {
			return ControlMessage{}, fmt.Errorf("decode tool invocation result: %w", err)
		}
		if result.InputID == "" || result.CallID == "" || (result.Status != "completed" && result.Status != "failed" && result.Status != "canceled") || len(result.Text) > 4096 || len(result.Error) > 2048 {
			return ControlMessage{}, fmt.Errorf("invalid structural control result")
		}
		request.Parameters = result
	case StopHard, StopWhenIdle, Compact:
	case CompactionDisabled:
		if strings.TrimSpace(request.Reason) == "" {
			return ControlMessage{}, fmt.Errorf("compaction disabled reason is empty")
		}
	case SetCompactionPolicy:
		var policy CompactionPolicy
		if err := json.Unmarshal(envelope.Parameters, &policy, json.RejectUnknownMembers(true)); err != nil {
			return ControlMessage{}, fmt.Errorf("decode compaction policy: %w", err)
		}
		if policy.FailureLimit <= 0 {
			return ControlMessage{}, fmt.Errorf("compaction failure limit must be positive")
		}
		request.Parameters = policy
	case Heartbeat:
		if request.Reason == "" {
			return ControlMessage{}, fmt.Errorf("heartbeat reason is empty")
		}
	case UpdateSettings:
		if len(envelope.Parameters) == 0 || string(envelope.Parameters) == "null" {
			return ControlMessage{}, fmt.Errorf("settings parameters are missing")
		}
		var settings Settings
		if err := json.Unmarshal(envelope.Parameters, &settings, json.RejectUnknownMembers(true)); err != nil {
			return ControlMessage{}, fmt.Errorf("decode settings parameters: %w", err)
		}
		if settings.ReasoningEffort != "" && !settings.ReasoningEffort.Valid() {
			return ControlMessage{}, fmt.Errorf("unsupported reasoning effort %q", settings.ReasoningEffort)
		}
		if settings.Model != "" && strings.TrimSpace(settings.Model) == "" {
			return ControlMessage{}, fmt.Errorf("model ID is empty")
		}
		if settings.CompactionThreshold != nil && *settings.CompactionThreshold < 0 {
			return ControlMessage{}, fmt.Errorf("compaction threshold must not be negative")
		}
		if settings.MaxOutputTokens != nil && *settings.MaxOutputTokens <= 0 {
			return ControlMessage{}, fmt.Errorf("max output tokens must be positive")
		}
		request.Parameters = settings
	default:
		return ControlMessage{}, fmt.Errorf("unsupported control mode %q", request.Mode)
	}
	return request, nil
}

type Writer interface {
	Submit(context.Context, Input) error
}

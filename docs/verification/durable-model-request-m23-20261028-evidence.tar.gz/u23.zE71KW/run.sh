python3 -I '/data/development/projects/0x7067/unreal-agent/.claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py' '/data/development/projects/0x7067/unreal-agent' '/tmp/u23.zE71KW' > '/tmp/u23.zE71KW'/driver.log 2>&1
rc=$?
printf "%s\n" "$rc" > '/tmp/u23.zE71KW'/exit-code
exit "$rc"

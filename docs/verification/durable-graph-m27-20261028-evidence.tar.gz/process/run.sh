#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
go test ./cmd/internal/workerhost -run '^TestM27DurableGraphWorkerRecovery$' -count=1 -v >'/tmp/unreal-agent-m27-process.zZWEEm/test.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m27-process.zZWEEm/exit-code';exit $rc

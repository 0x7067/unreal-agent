#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
go test -race ./cmd/internal/workerhost -run '^TestM27DurableGraphWorkerRecovery$' -count=10 -v >'/tmp/unreal-agent-m27-isolated.1Px1pW/graph.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m27-isolated.1Px1pW/graph.exit-code';exit $rc

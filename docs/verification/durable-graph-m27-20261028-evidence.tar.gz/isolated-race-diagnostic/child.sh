#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
go test -race ./cmd/internal/durablechild -run '^TestIndependentChildSurvivesParentSIGKILL/child_interrupted$' -count=1 -v >'/tmp/unreal-agent-m27-isolated.1Px1pW/child.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m27-isolated.1Px1pW/child.exit-code';exit $rc

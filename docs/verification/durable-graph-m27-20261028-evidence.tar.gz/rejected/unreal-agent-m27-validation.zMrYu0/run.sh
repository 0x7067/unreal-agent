python3 '/tmp/unreal-agent-m27-validation.zMrYu0/manifest.py' > '/tmp/unreal-agent-m27-validation.zMrYu0/source.before.sha256'
rc=0
for phase in check build test; do
 printf '%s\n' "$phase" > '/tmp/unreal-agent-m27-validation.zMrYu0/phase'
 make "$phase" > '/tmp/unreal-agent-m27-validation.zMrYu0'/make-"$phase".log 2>&1
 rc=$?
 if [ "$rc" != 0 ]; then break;fi
done
python3 '/tmp/unreal-agent-m27-validation.zMrYu0/manifest.py' > '/tmp/unreal-agent-m27-validation.zMrYu0/source.after.sha256'
if ! cmp -s '/tmp/unreal-agent-m27-validation.zMrYu0/source.before.sha256' '/tmp/unreal-agent-m27-validation.zMrYu0/source.after.sha256';then rc=97;fi
printf '%s\n' "$rc" > '/tmp/unreal-agent-m27-validation.zMrYu0/exit-code.tmp';mv '/tmp/unreal-agent-m27-validation.zMrYu0/exit-code.tmp' '/tmp/unreal-agent-m27-validation.zMrYu0/exit-code'
printf '%s\n' finished > '/tmp/unreal-agent-m27-validation.zMrYu0/phase'
exit "$rc"

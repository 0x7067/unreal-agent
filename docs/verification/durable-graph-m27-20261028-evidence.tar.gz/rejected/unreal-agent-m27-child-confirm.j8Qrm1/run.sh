#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
go test -race ./cmd/internal/durablechild -run '^TestIndependentChildSurvivesParentSIGKILL/child_interrupted$' -count=3 -v >'/tmp/unreal-agent-m27-child-confirm.j8Qrm1/test.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m27-child-confirm.j8Qrm1/exit-code';exit $rc

#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
python3 -I .claude/skills/verify-unreal-agent-tui/scripts/durable_lifecycle.py '/data/development/projects/0x7067/unreal-agent' '/tmp/u27.24q8KP' >'/tmp/unreal-agent-m27-ui.CjflHH/lifecycle.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m27-ui.CjflHH/lifecycle.exit-code';exit $rc

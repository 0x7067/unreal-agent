#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
python3 -I .claude/skills/verify-unreal-agent-tui/scripts/durable_reconnect.py '/data/development/projects/0x7067/unreal-agent' '/tmp/u27.Be7VJz' >'/tmp/unreal-agent-m27-ui.CjflHH/reconnect.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m27-ui.CjflHH/reconnect.exit-code';exit $rc

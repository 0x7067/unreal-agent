#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
go test -race ./cmd/internal/resident -run '^TestLifecycleRealLostAckRetryCannotAbortNewTurn$' -count=5 -v >'/tmp/unreal-agent-m27-resident-repeat.wivzDt/test.log' 2>&1
rc=$?;echo $rc >'/tmp/unreal-agent-m27-resident-repeat.wivzDt/exit-code';exit $rc

#!/bin/sh
cd /data/development/projects/0x7067/unreal-agent
git hash-object harness/taskgraph/graph.go >'/tmp/unreal-agent-m27-safety.3fKjU5/graph.before'
go test ./harness/taskgraph -run TestGraphExhaustiveSafety -count=1 -v >'/tmp/unreal-agent-m27-safety.3fKjU5/test.log' 2>&1
rc=$?;git hash-object harness/taskgraph/graph.go >'/tmp/unreal-agent-m27-safety.3fKjU5/graph.after';echo $rc >'/tmp/unreal-agent-m27-safety.3fKjU5/exit-code';exit $rc

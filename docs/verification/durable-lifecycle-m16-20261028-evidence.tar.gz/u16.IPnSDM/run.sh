python3 -I '/data/development/projects/0x7067/unreal-agent/.claude/skills/verify-unreal-agent-tui/scripts/durable_reconnect.py' '/data/development/projects/0x7067/unreal-agent' '/tmp/u16.IPnSDM' > '/tmp/u16.IPnSDM'/driver.log 2>&1
rc=$?
printf "%s\n" "$rc" > '/tmp/u16.IPnSDM'/exit-code
exit "$rc"
